<?php

namespace Drupal\smsa_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'ShippingRateBlock' block.
 *
 * @Block(
 *  id = "shipping_rate_block",
 *  admin_label = @Translation("Shipping Rate Block"),
 * )
 */
class ShippingRateBlock extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'shipping_rate_block',
      '#variables' => NULL,
    );
  }
}