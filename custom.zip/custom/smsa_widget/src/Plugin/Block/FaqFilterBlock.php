<?php

namespace Drupal\smsa_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'FaqFilterBlock' block.
 *
 * @Block(
 *  id = "faq_filter_block",
 *  admin_label = @Translation("Faq Filter Block"),
 * )
 */
class FaqFilterBlock extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'faq_filter_block',
      '#variables' => NULL,
    );
  }
}