<?php

namespace Drupal\smsa_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'LanguageSwitcherBlock' block.
 *
 * @Block(
 *  id = "language_switcher_block",
 *  admin_label = @Translation("Language Switcher Block Block"),
 * )
 */
class LanguageSwitcherBlock extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'language_switcher_block',
      '#variables' => NULL,
    );
  }
}