<?php

namespace Drupal\smsa_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'ServicesCarousalBlock' block.
 *
 * @Block(
 *  id = "services_carousal_block",
 *  admin_label = @Translation("Services Carousel Block"),
 * )
 */
class ServicesCarousalBlock extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'services_carousal_block',
      '#variables' => NULL,
    );
  }
}