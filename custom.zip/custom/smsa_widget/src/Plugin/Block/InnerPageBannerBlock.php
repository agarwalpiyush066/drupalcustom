<?php

namespace Drupal\smsa_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'InnerPageBannerBlock' block.
 *
 * @Block(
 *  id = "inner_page_banner_block",
 *  admin_label = @Translation("Inner Page Banner Block"),
 * )
 */
class InnerPageBannerBlock extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'inner_page_banner_block',
      '#variables' => NULL,
    );
  }
}