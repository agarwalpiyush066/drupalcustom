<?php

namespace Drupal\smsa_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'AwbTrackingBlock' block.
 *
 * @Block(
 *  id = "awb_tracking_block",
 *  admin_label = @Translation("AWB Tracking Block"),
 * )
 */
class AwbTrackingBlock extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'awb_tracking_block',
      '#variables' => NULL,
    );
  }
}