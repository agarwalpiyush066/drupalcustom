<?php

namespace Drupal\smsa_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'MobileNavigationBlock' block.
 *
 * @Block(
 *  id = "mobile_navigation_block",
 *  admin_label = @Translation("Mobile Navigation Block"),
 * )
 */
class MobileNavigationBlock extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'mobile_navigation_block',
      '#variables' => NULL,
    );
  }
}