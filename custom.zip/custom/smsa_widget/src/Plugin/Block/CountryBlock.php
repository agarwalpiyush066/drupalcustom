<?php

namespace Drupal\smsa_widget\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'CountryBlock' block.
 *
 * @Block(
 *  id = "country_block",
 *  admin_label = @Translation("Country Select Block"),
 * )
 */
class CountryBlock extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'country_select_block',
      '#variables' => NULL,
    );
  }
}