<?php

/**
 * @file
 * Contains \Drupal\smsa_widget\Form\FaqFilterForm.
 */

namespace Drupal\smsa_widget\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

class FaqFilterForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'faq_filter_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['title'] = [
      '#type' => 'textfield',
      '#attributes' => array(
        'placeholder' => t('Search your query'),
      ),
      '#default_value' => !empty($_GET['title']) ? $_GET['title'] : '',
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Apply'),
    );

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $title = $form_state->getValue('title');
    if ($title) {
      // Redirect to FAQ page.
      $form_state->setRedirect('view.faq_listing.page_1', ['title' => $title]);
    }
  }

}
