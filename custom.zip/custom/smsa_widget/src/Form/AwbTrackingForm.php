<?php

/**
 * @file
 * Contains \Drupal\smsa_widget\Form\AwbTrackingForm.
 */

namespace Drupal\smsa_widget\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

class AwbTrackingForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'awb_tracking_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['awb'] = [
      '#type' => 'textarea',
      '#title' => t('TRACK AND TRACE'),
       '#attributes' => array(
        'placeholder' => t('Enter your tracking No.'),
      ),
      '#required' => TRUE,
      '#description' => '<p>' . t('Separate multiple tracking numbers with a space or comma') . '</p>',
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('TRACK NOW'),
      '#button_type' => 'primary',
      '#attributes' => array('class' => array('custom-all-btn')),
    );

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    //if(!is_numeric($form_state->getValue('awb'))){
      //    $form_state->setErrorByName('awb', $this->t('Please insert valid Airway bill number'));    
    //}
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $awb = $form_state->getValue('awb');

    // Separate by space.
    $awbNos = explode(' ', $awb);

    if (strstr($awb, ',')) {
      // Separate by comma.
      $awbNos = explode(',', $awb);
    }
    if(strpos($form_state->getValue('awb' ), "\n") !== FALSE) {
      $awbNos = explode("\n", $awb);
    }

    $awbArr = [];
    if (count($awbNos)) {
      foreach ($awbNos as $awbNo) {
        $awbNo = trim($awbNo);
        if (is_numeric($awbNo)) {
          $awbArr[] = $awbNo;
        }
      }
    }

    // Redirect to tracking details page.
    $form_state->setRedirect('smsa_widget.awb_tracking_details', ['tracknumbers' => $awbArr]);
  }

}
