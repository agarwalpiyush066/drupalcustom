<?php

/**
 * @file contains
 */

namespace Drupal\smsa_widget\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;
use SoapClient;

class TrackingController extends ControllerBase {

  // API to track 15 digit tracking number.
  const TRACK_15_WSDL = "http://track.smsaexpress.com/secom/smsamobileapp.asmx?op=getTracking&wsdl";
  // API to track 12 digit tracking number.
  const TRACK_12_WSDL = "http://strack.cloudapp.net/trackSMSA.svc?singleWsdl";
  const TRACK_12_WSDL_NEW = "http://smsaweb.cloudapp.net:8080/track.svc?wsdl";
  const TRACK_15_PASSKEY = 'SMSA@x6iNa';
  const TRACK_12_USERNAME = 'website';
  const TRACK_12_PASSWORD = 'Smsa1234';

  /**
   * Fetch tracking details for provided awb nos.
   *
   * @param Symfony\Component\HttpFoundation\Request $request
   *   Request object.
   *
   * @return array
   *   Renderable array.
   */
  public function getDetails(Request $request) {
    //\Drupal::service('page_cache_kill_switch')->trigger();
    $tracknumbers = \Drupal::request()->query->get('tracknumbers');
    $tracking_form = \Drupal::formBuilder()->getForm('Drupal\smsa_widget\Form\AwbTrackingForm');
    $trackingDetails = [];
    if(is_string($tracknumbers) && $tracknumbers != ""){
      $tracknumberss[]= $tracknumbers;
      $tracknumbers = $tracknumberss;
    }
    if (count($tracknumbers)) {

      foreach ($tracknumbers as $tracknumber) {

        if (strlen($tracknumber) == 15) {

          $trackParams = [
            'wsdl' => self::TRACK_15_WSDL,
            'function' => 'getTracking',
            'args' => [
              'awbNo' => $tracknumber,
              'passkey' => self::TRACK_15_PASSKEY,
            ],
          ];
        }
        else {
          //continue;
/*
          $trackParams = [
            'wsdl' => self::TRACK_12_WSDL_NEW,
            'function' => 'getSMSATracking',
            'args' => [
              //'RequestData'=>[
              'awb' => $tracknumber,
              'lang' => 'EN',
              'password' => self::TRACK_12_PASSWORD,
              'username' => self::TRACK_12_USERNAME,
             // ]
            ],
            ];
            */


            $trackParams = [
            'wsdl' => self::TRACK_12_WSDL,
            'function' => 'AllTrackDetails',
            'args' => [
              'RequestData'=>[
                'AWB' => $tracknumber,
                'Language' => \Drupal::languageManager()->getCurrentLanguage()->getId(),//'',
                'Password' => self::TRACK_12_PASSWORD,
                'Username' => self::TRACK_12_USERNAME,
                ]],
            ];

        }

        // Fetch data from SOAP API.
        $trackingDetails[$tracknumber] = $this->_fetchTrackingDetails($trackParams);
      }
     // echo "<pre>";
      //print_r($trackingDetails);
    //  exit;
    }

    return [
      '#theme' => 'awb_tracking',
      '#results' => $trackingDetails,
      '#tracking_form' => $tracking_form,
    ];
  }

  /**
   * Fetch tracking details from SOAP API(s).
   *
   * @param array $soapParams
   *   Parameters for API call.
   *
   * @return
   */
  private function _fetchTrackingDetails(array $soapParams) {

    try {
      // Initialize SOAP client.
      $soapClient = new SoapClient($soapParams['wsdl']);

      $soapClientFn = $soapParams['function'];
      $response = $soapClient->$soapClientFn($soapParams['args']);
      //print_r($response);exit();
      unset($soaClient);

      $processedTrackingDetails = $this->_processTrackingResponse($soapParams['wsdl'], $response);

      return $processedTrackingDetails;
    }
    catch (\RuntimeException $e) {
      // Logs an error
      \Drupal::logger('smsa_widget')->error('Error while consuming API:' . $e->getMessage());
    }
  }

  private function _processTrackingResponse(string $type, $response) {

    $details = [];
    if ($type == self::TRACK_15_WSDL) {
      // Shipping details.
      $details['shippingDetails'] = (array) $response->getTrackingResult->ShipmentDetails;
      $details['shippingDetails']['AirWaybill'] = '#' . $details['shippingDetails']['AirWaybill'];
      $details['shippingDetails']['ShipDate'] = date('D, d M Y', strtotime($details['shippingDetails']['ShipDate']));

      // Tracking Details.
      if (isset($response->getTrackingResult->TrackingDetailsList->TrackingDetails)) {
        $trackingDetails = (array) $response->getTrackingResult->TrackingDetailsList->TrackingDetails;
	$api_type = 15;
        $details['trackingDetails'] = $this->_sortTrackingDetailsByDate($trackingDetails,$api_type);
        $details['trackingStatus'] = $this->_getTrackingStatus($trackingDetails);
        $details['status'] = (isset($trackingDetails[0]->EventDesc)) ? $trackingDetails[0]->EventDesc : "IDLE";
      }
    }
    else {
      // Shipping details.
      $details['shippingDetails'] = (array) $response->AllTrackDetailsResult->ShipmentDetails;
      $details['shippingDetails']['AirWaybill'] = '#' . $details['shippingDetails']['AirWaybill'];
      $details['shippingDetails']['ShipDate'] = date('D, d M Y', strtotime($details['shippingDetails']['ShipDate']));
      $details['shippingDetails']['ShipmentWeight']= (String)$details['shippingDetails']['ShipmentWeight'];
      $details['shippingDetails']['ShipmentPieces']= (String)$details['shippingDetails']['ShipmentPieces'];
      // Tracking Details.
      if (isset($response->AllTrackDetailsResult->TrackingDetailsList->TrackingDetails)) {
        $trackingDetails = (array) $response->AllTrackDetailsResult->TrackingDetailsList->TrackingDetails;
	$api_type = 12;
        $details['trackingDetails'] = $this->_sortTrackingDetailsByDate($trackingDetails,$api_type);
        $details['trackingStatus'] = $this->_getTrackingStatus($trackingDetails);
        $details['status'] = (isset($trackingDetails[0]->EventDesc)) ? $trackingDetails[0]->EventDesc : "IDLE";
//echo "<pre>";print_r($trackingDetails);exit;
        if(isset($trackingDetails['EventDesc'])){
          $details['status'] = $trackingDetails['EventDesc'];
        }
      }
    }

    return $details;
  }

  private function _sortTrackingDetailsByDate(array $trackingDetails, $api_type) {
    $sortedDetails = [];
    if (count($trackingDetails)) {
      // Sort by date.
      if(is_object($trackingDetails[0])){
        foreach ($trackingDetails as $trackingData) {
          $trackingData = (array) $trackingData;
          if(empty($trackingData['EventDate'])){
            $trackingData['EventDate']=$trackingData['EventTime'];
          }
          $after3Hour = strtotime('+3 hour', strtotime($trackingData['EventDate']));
          $date = date('d-M-Y', strtotime($trackingData['EventDate']));
          $trackingData['EventDisplayDate'] = $date;
          $trackingData['EventTime'] = date('h:i A', strtotime($trackingData['EventDate']));
          $trackingData['EventDay'] = date('l', strtotime($trackingData['EventDate']));
  	      if($api_type == 12){	
           $trackingData['EventDisplayDate'] = date('d-M-Y', $after3Hour);
   		     $trackingData['EventTime'] = date('h:i A', $after3Hour);
           $trackingData['EventDay'] = date('l', $after3Hour);

        	}
          $sortedDetails[$date][] = $trackingData;
        }
      }else{
          $trackingData = (array) $trackingDetails;
          if(empty($trackingData['EventDate'])){
            $trackingData['EventDate']=$trackingData['EventTime'];
          }
          $after3Hour = strtotime('+3 hour', strtotime($trackingData['EventDate']));
          $date = date('d-M-Y', strtotime($trackingData['EventDate']));
          $trackingData['EventDisplayDate'] = $date;
          $trackingData['EventTime'] = date('h:i A', strtotime($trackingData['EventDate']));
          $trackingData['EventDay'] = date('l', strtotime($trackingData['EventDate']));
          if($api_type == 12){  
           $trackingData['EventDisplayDate'] = date('d-M-Y', $after3Hour);
           $trackingData['EventTime'] = date('h:i A', $after3Hour);
           $trackingData['EventDay'] = date('l', $after3Hour);

          }
          $sortedDetails[$date][] = $trackingData;
      }
    }

    return $sortedDetails;
  }

  private function _getTrackingStatus(array $trackingDetails) {
    if(is_object($trackingDetails[0])){
      $doneclass = 'done';
      $activeclass = 'active';
      $statusArray = [
        'IDLE' => $activeclass,
        'PickedUP' => false,
        'InTransit' => false,
        'OutForDelivery' => false,
        'Delivered' => false,
      ];

      if (count($trackingDetails)) {
        foreach ($trackingDetails as $trackingData) {
          $trackingData = (array) $trackingData;
          $pickup=stripos($trackingData['EventDesc'],"Picked Up");
          $delivered=stripos($trackingData['EventDesc'],"Delivered");

          switch ($trackingData['EventDesc']) {
            case $trackingData['EventDesc'] == 'Data Received':
            case $trackingData['EventDesc'] == 'Address validated':
            case $trackingData['EventDesc'] == 'Shipment Information Updated': 
            case ($trackingData['StatusCode'] == 'ADV') :
            case ($trackingData['StatusCode'] == 'Data') :
              break;

            //pickup
            case ($pickup!==FALSE) :
            case ($trackingData['StatusCode'] == 'PU'):
              $statusArray['IDLE'] = $doneclass;
              $statusArray['PickedUP'] = ((!empty($statusArray['InTransit'])) || ($statusArray['InTransit'] !== $activeclass )) ? $doneclass : $activeclass;
              break;

            //out for delivery  
            case 'OUT FOR DELIVERY':
            case 'Out for Delivery':
            case ($trackingData['StatusCode'] == 'OD'):
            case ($trackingData['StatusCode'] == 'WC'):
              $statusArray['IDLE'] = $doneclass;
              $statusArray['PickedUP'] = $doneclass;
              $statusArray['InTransit'] = $doneclass;
              $statusArray['OutForDelivery'] = ((!empty($statusArray['Delivered'])) || ($statusArray['Delivered'] !== $doneclass )) ? $doneclass : $activeclass;
              break;

            //delivered  
            case 'PROOF OF DELIVERY CAPTURED':
            case 'Proof of Delivery Captured':
            case 'Returned to Client':
            case 'Delivered':
            case ($delivered!==FALSE) :
            case ($trackingData['StatusCode'] == 'DL'):
            case ($trackingData['StatusCode'] == 'OK'):
            case ($trackingData['StatusCode'] == 'DEX09'):
              $statusArray['IDLE'] = $doneclass;
              $statusArray['PickedUP'] = $doneclass;
              $statusArray['InTransit'] = $doneclass;
              $statusArray['OutForDelivery'] = $doneclass;
              $statusArray['Delivered'] = $doneclass;
              break;

            //in transit  
            default:
              $statusArray['IDLE'] = $doneclass;
              $statusArray['PickedUP'] = $doneclass;
              $statusArray['InTransit'] = ((!empty($statusArray['OutForDelivery'])) || ($statusArray['OutForDelivery'] !== $activeclass )) ? $doneclass : $activeclass;
              break;
          }
        }
      }
      return $statusArray;
    }else{
      $doneclass = 'done';
      $activeclass = 'active';
      $statusArray = [
        'IDLE' => $activeclass,
        'PickedUP' => false,
        'InTransit' => false,
        'OutForDelivery' => false,
        'Delivered' => false,
      ];

      if (count($trackingDetails)) {
        $trackingData = (array) $trackingDetails;
        $pickup=stripos($trackingData['EventDesc'],"Picked Up");
        $delivered=stripos($trackingData['EventDesc'],"Delivered");

        switch ($trackingData['EventDesc']) {
          case $trackingData['EventDesc'] == 'Data Received':
          case $trackingData['EventDesc'] == 'Address validated':
          case $trackingData['EventDesc'] == 'Shipment Information Updated': 
          case ($trackingData['StatusCode'] == 'ADV') :
          case ($trackingData['StatusCode'] == 'Data') :
            break;

          //pickup
          case ($pickup!==FALSE) :
          case ($trackingData['StatusCode'] == 'PU'):
          case ($trackingData['StatusCode'] == 'PR'):
            $statusArray['IDLE'] = $doneclass;
            $statusArray['PickedUP'] = ((!empty($statusArray['InTransit'])) || ($statusArray['InTransit'] !== $activeclass )) ? $doneclass : $activeclass;
            break;

          //out for delivery  
          case 'OUT FOR DELIVERY':
          case 'Out for Delivery':
          case ($trackingData['StatusCode'] == 'OD'):
          case ($trackingData['StatusCode'] == 'WC'):
            $statusArray['IDLE'] = $doneclass;
            $statusArray['PickedUP'] = $doneclass;
            $statusArray['InTransit'] = $doneclass;
            $statusArray['OutForDelivery'] = ((!empty($statusArray['Delivered'])) || ($statusArray['Delivered'] !== $doneclass )) ? $doneclass : $activeclass;
            break;

          //delivered  
          case 'PROOF OF DELIVERY CAPTURED':
          case 'Proof of Delivery Captured':
          case 'Returned to Client':
          case 'Delivered':
          case ($delivered!==FALSE) :
          case ($trackingData['StatusCode'] == 'DL'):
          case ($trackingData['StatusCode'] == 'OK'):
          case ($trackingData['StatusCode'] == 'DEX09'):
            $statusArray['IDLE'] = $doneclass;
            $statusArray['PickedUP'] = $doneclass;
            $statusArray['InTransit'] = $doneclass;
            $statusArray['OutForDelivery'] = $doneclass;
            $statusArray['Delivered'] = $doneclass;
            break;

          //in transit  
          default:
            $statusArray['IDLE'] = $doneclass;
            $statusArray['PickedUP'] = $doneclass;
            $statusArray['InTransit'] = ((!empty($statusArray['OutForDelivery'])) || ($statusArray['OutForDelivery'] !== $activeclass )) ? $doneclass : $activeclass;
            break;
          }
      }
      return $statusArray;
    }
  }
}
