function test() {
    jQuery('.country-select .dropdown-item .text span').each(function (index) {
        var cl = jQuery(this).attr("class");
        jQuery(this).css({"background-image": "url('/themes/custom/smsa/images/flags/" + cl + ".png')", "background-repeat": "no-repeat"});
    });

}

function test_data() {
    setTimeout(function () {
        jQuery('.country-select .dropdown button').attr("onclick", "test()");
    }, 1000);

    var selected_cls = jQuery('#countries').val();
    setTimeout(function () {
        jQuery('span.' + selected_cls).css({"background-image": "url('/themes/custom/smsa/images/flags/" + selected_cls + ".png')", "background-repeat": "no-repeat"});
    }, 1000);


    jQuery('#countries').on('change', function () {
        var selected_on_cls = jQuery(this).val();
        setTimeout(function () {
            jQuery('span.' + selected_on_cls).css({"background-image": "url('/themes/custom/smsa/images/flags/" + selected_on_cls + ".png')", "background-repeat": "no-repeat"});
        }, 500);
    });

    /*homepage service slider on hover*/
    // jQuery('.carousel-indicators  li').on('mouseover', function () {
    //     /*jQuery(this).trigger('click');*/
    //     var goTo = jQuery(this).data('slide-to');
    //     jQuery('#carouselExampleIndicators').carousel(goTo);
    // }) 
    jQuery('.carousel-indicators  li').on('click', function () {
        /*jQuery(this).trigger('click');*/
        var goTo = jQuery(this).data('slide-to');
        jQuery('#carouselExampleIndicators').carousel(goTo);
       // event.preventDefault();
    }) 
}
//jQuery(document).ready(function () {
jQuery(window).on('load', function() {
    test_data();
});
jQuery(function() { 
    test_data();
});

jQuery(document).ready(function () {
    jQuery(".my_tracking_form").hide();
    jQuery(".my_tracking_text").click(function(){
      jQuery(".my_tracking_form").show();
      jQuery(".my_tracking_text").hide();
    });

    jQuery.each(jQuery("#block-smsa-footer .nav-link"), function(){
        if(jQuery(this).text() == 'hide'){
          jQuery(this).hide();
    }});
    
    jQuery('.trk-wrap h4').html(function(i, text) {
         return text.replace(
             /\bhttps:\/\/([\w\.-]+\.)+[a-z]{2,}\/.+\b/gi,
             '<a href="$&">$&</a>'
         );
    })
});

(function ($) {
    // Drupal's core beforeSend function
    var beforeSend = Drupal.ajax.prototype.beforeSend;

    // Add a trigger when beforeSend fires.
    Drupal.ajax.prototype.beforeSend = function (xmlhttprequest, options) {
        // Only apply our override on specific fields.
        if (this.element.name == "field_name") {
            // Copied and modified from Drupal.ajax.prototype.beforeSend in ajax.js
            $(this.element).addClass('progress-disabled').attr('disabled', true);
            // Modify the actualy progress throbber HTML.
            this.progress.element = $('<div class="ajax-progress ajax-progress-throbber"><div class="throbber">&nbsp;</div><div class="message">Loading</div></div>');
            // Change the position of the throbber.
            $(this.element).parent().parent().after(this.progress.element);
        } else {
            // Send to the default Drupal Ajax function if we're not looking at our specific field.
            beforeSend.call(this, xmlhttprequest, options);
            $(document).trigger('beforeSend');
        }
    };
} (jQuery));