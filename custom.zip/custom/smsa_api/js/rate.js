(function($, Drupal) {
  Drupal.behaviors.shippingRateJSBehavior = {
    attach: function(context, settings) {
      var productSelector = $(".shipping-product");
      productSelector.first().prop('checked', true);
      var price = productSelector.first().val();
      price =  parseFloat(price).toFixed(2);
      var currency = productSelector.first().data('currency');
      var vatamount = productSelector.first().data('vatamount');
      var vatper = productSelector.first().data('vatper');
      var total = parseFloat(price) + parseFloat(vatamount); 
      jQuery('.shipping-rate .price').html(total);
      jQuery('.shipping-vat .price').html(price);
      jQuery('.shipping-rate .currency').html(currency);
      jQuery('.shipping-vat .vat').html(vatamount);
      jQuery('.shipping-vat .vatper').html(vatper);

      $("input[name='rbtproduct']").click(function() {
        price = this.value;
        price =  parseFloat(price).toFixed(2);
        currency = $(this).data('currency');
        vatamount = $(this).data('vatamount');
        vatper = $(this).data('vatper');
        $('.shipping-rate, .shipping-vat').hide();
        $('.shipping-rate .price, .shipping-vat .price,.shipping-rate .currency').html('');
        setTimeout(function() {
          var total = parseFloat(price) + parseFloat(vatamount); 
          jQuery('.shipping-rate .price').html(total);
          jQuery('.shipping-vat .price').html(price);
          jQuery('.shipping-rate .currency').html(currency);
          jQuery('.shipping-vat .vat').html(vatamount);
          jQuery('.shipping-vat .vatper').html(vatper);
          $('.shipping-rate, .shipping-vat').show();
        }, 500);

      });

      if (drupalSettings.shippingblock.isfront) {
        jQuery(window).on('load', function() {
          $("select[name='from_country']").on('change', function() {
            $(".js-form-item-from-country .filter-option-inner-inner").text($(this).find("option:selected").data('code'));
          }).change();

          $("select[name='to_country']").on('change', function() {
            $(".js-form-item-to-country .filter-option-inner-inner").text($(this).find("option:selected").data('code'));
          }).change();
        });
      }

      jQuery('input[type="radio"]').click(function(){
        var inputValue = jQuery(this).attr("value");
        if (inputValue == 'kg') {
            jQuery('#edit-weight').attr("placeholder", "0.0 KG");        
        }else{
            jQuery('#edit-weight').attr("placeholder", "0.0 LBS");        
        }
      });
        jQuery('#shipping-rate-enquiry #edit-weight, #shipping-rate-enquiry-main #edit-weight').on('change invalid', function() {
            var textfield = jQuery(this).get(0); 
            textfield.setCustomValidity('');
            if (!textfield.validity.valid) {
                if (window.location.href.indexOf("ar") > -1) {
                    var message = 'أدخل الوزن التقريبي للشحنة';
                }else{
                    var message = 'Please enter estimated weight of shipment';
                }
              textfield.setCustomValidity(message);  
            }
        });

    }
  };
})(jQuery, Drupal);

jQuery(document).ready(function () {
  jQuery('#edit-to-country').on('change', function() {
    jQuery( "#edit-from-city" ).removeClass( "hidemeplease" )
  });
  jQuery('#edit-from-country').on('change', function() {
    jQuery( "#edit-to-city" ).removeClass( "hidemeplease" )
  });

  var country_from = jQuery('#edit-from-country').find(":selected").text();
  var city_from = jQuery('#edit-from-city').find(":selected").text();
  var country_to = jQuery('#edit-to-country').find(":selected").text();
  var city_to = jQuery('#edit-to-city').find(":selected").text();


  if( country_from != '- Select -' && country_from != '- اختر -' ){
    jQuery('.country_from').text(country_from);
  }
  if( country_to != '- Select -' && country_to != '- اختر -' ){
    jQuery('.country_to').text(country_to);
    jQuery('.icon_show').addClass('ship_icon');
  }
  if( city_from != 'Select City' && city_from != 'اختر مدينة' ){
    jQuery('.country_from').append('<span>('+city_from+')</span>');
  }
  if( city_to != 'Select City' && city_to != 'اختر مدينة' ){
    jQuery('.country_to').append('<span>('+city_to+')</span>');
  }

});
