<?php

namespace Drupal\smsa_api\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Url;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Ajax\InsertCommand;
use Drupal\Core\Locale\CountryManager;
use SoapClient;
use Throwable;
class ShippingRateEnquiryMainForm extends FormBase {

  /**
   * @inheritDoc
   */
  public function getFormId() {
    return 'shipping_rate_enquiry_main';
  }

  /**
   * @inheritDoc
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    
    $weight =  \Drupal::request()->query->get('weight');
    $frcountry =  \Drupal::request()->query->get('fcountry');
    $fcountry = str_replace(" ","_", $frcountry);   
    $tocountry =  \Drupal::request()->query->get('tcountry');
    $t_country = str_replace(" ","_", $tocountry);
    $f_city=  \Drupal::request()->query->get('fcity');
    $t_city= \Drupal::request()->query->get('tcity');
    $get_capital= '';
    $status_display = 'hidemeplease';
    if($fcountry == $t_country) {
      $get_capital = $this->apiRequestForcapital($fcountry);
      if($f_city) {
        $get_capital = $f_city;
      }
      $get_capital1 = $this->apiRequestForcapital($fcountry);
      if($t_city) {
        $get_capital1 = $t_city;
      }
      $status_display = 'showmeplease';
    }
    if($fcountry != $t_country) {
      if($f_city) {
        $get_capital = $f_city;
      }
      if($t_city) {
        $get_capital1 = $t_city;
      }
    }
    //$get_capital = $this->apiRequestForcapital($fcountry);  


    //$tcountry = isset($tcountry) ? $tcountry : 'United_Arab_Emirates';

    $weight_type =  \Drupal::request()->query->get('weight_type');
    $weight_type = isset($weight_type) ? $weight_type : 'kg';
    $base_path = \Drupal::request()->getSchemeAndHttpHost();
    $theme = \Drupal::theme()->getActiveTheme();
    $country_list = [];
    $countries = \Drupal\Core\Locale\CountryManager::getStandardList();
    foreach ($countries as $country_code => $country_display_name) {
      $country_name = str_replace(" ", "_", $country_display_name);
      $country_list[$this->countryCodeToCountry($country_code)] = $country_display_name;
    }

    $form['#prefix'] = "<img src='".$base_path.$theme->getPath() ."/images/block-images/shipping_rate.png' alt='shipping-rate'>";


    $form['from_country'] = array(
      '#type' => 'select',
      '#title' => $this->t('From Country'),
      '#validated' => TRUE,
      '#options' => $this->getCountries(),
      '#ajax' => array(
        'callback' => '::findfromCityCallback',
        'wrapper' => 'edit-from-city',
        'effect' => 'fade',
        'event' => 'change',
        'method'=>'replace',
        'progress' => array(
             'type' => 'throbber',
             'message' => NULL,
        ),
        '#attributes' => array(
          'name' => 'from_country'
        ),
      ),
      '#required'=>true,
      '#default_value' =>$frcountry ,
    );
    

    $from_city_opt = isset($frcountry)?$frcountry :$form_state->getValue('from_country');

    $form['from_city'] = array(
      '#type' => 'select',
      '#title' => $this->t('From city'),
      '#empty_option' => t('Select City'),
      '#validated' => TRUE,
      '#options'=>  $this->apiRequestForfromcity($from_city_opt),
      '#prefix' => '<div class="'.$status_display.'" id="edit-from-city">', '#suffix' => '</div>',
      '#required'=>false,
      '#default_value' => $get_capital,
    );
    
    $form['to_country'] = array(
      '#type' => 'select',
      '#title' => $this->t('To Country'),
      '#validated' => TRUE,
      '#options' => $this->toCountries(),
      '#ajax' => array(
        'callback' => '::findtoCityCallback',
        'wrapper' => 'edit-to-city',
        'effect' => 'fade',
        'event' => 'change',
        'method'=>'replace',
        'progress' => array(
             'type' => 'throbber',
             'message' => NULL,
        ),
        '#attributes' => array(
          'name' => 'to_country'
        ),
      ),
      '#required'=>true,
      '#default_value' => $tocountry,
    );
    $to_city_opt = isset($tocountry)?$tocountry :$form_state->getValue('to_country');

    $form['to_city'] = array(
      '#type' => 'select',
      '#validated' => TRUE,
      '#title' => $this->t('To city'),
      "#empty_option" => t('Select City'),
      '#options'=> $this->apiRequestFortocity($to_city_opt),
      '#prefix' => '<div class="'.$status_display.'" id="edit-to-city">', '#suffix' => '</div>',
      '#required'=>false,
      '#default_value' => $get_capital1,
    );
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
      if( $language == 'ar' ){
        $msg = 'أدخل الوزن التقريبي للشحنة';
      }else{
         $msg = 'Please enter estimated weight of shipment'; 
      }
    $form['weight'] = array(
      '#type' => 'textfield',
      '#attributes' => array(
        'data-type' => 'number',
        'placeholder' => t('0.0 KG'),
        'title' => $msg
      ),
      '#required' => TRUE,
      '#default_value' => $weight,
    );

    $form['weight_type'] = [
      '#type' => 'radios',
      '#required' => true,
      '#options' => [
        'kg' => t('Kg'),
        'lbs' => t('Lbs'),
      ],
      '#default_value' => $weight_type,
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('CHECK RATES'),
      '#button_type' => 'primary',
      '#attributes' => array('class' => array('custom-all-btn')),
    );
    $form['#attached'] = [
      'library' => array('smsa_api/rate'),
    ];
    $form['#attached']['drupalSettings']['shippingblock']['isfront'] = \Drupal::service('path.matcher')->isFrontPage();

    return $form;
  }


/**
 * {@inheritdoc}
 */
  public function validateForm(array &$form, \Drupal\Core\Form\FormStateInterface $form_state) {
    if(!is_numeric($form_state->getValue('weight'))){
          $form_state->setErrorByName('weight', $this->t('Please insert valid weight'));    
    }
  }
  /**
   * @inheritDoc
   */
  public function submitForm(array &$form, \Drupal\Core\Form\FormStateInterface $form_state) {
    //$to_country = $form_state->getValue('to_country');
    //$from_country=$form_state->getValue('from_country');
    $to_city= $form_state->getValue('to_city');
    $from_city= $form_state->getValue('from_city');
    $fromc=$form_state->getValue('from_country');
    $f_country = str_replace("_"," ", $fromc);
    $to_country = $form_state->getValue('to_country');
    $t_country = str_replace("_"," ", $to_country);
    //$to_country = str_replace("_", " ", $country_name);

    # set form data in url redirect
    $option = [
      'query' => ['fcountry' => $f_country, 'tcountry' =>
        $t_country , 'fcity' => $from_city,'tcity' => $to_city,'weight' => $form_state->getValue('weight'),'weight_type' => $form_state->getValue('weight_type')],
    ];
    $url = Url::fromUri('internal:/shipping-rate', $option);
    $form_state->setRedirectUrl($url);
  }

  public function apiRequestForcapital($country)
  {  
    
    $tocapital=[
       'country'=>  str_replace("_", " ", $country),
       'passkey' => 'rcc$ervice',
       'language' => 'En'
    ];
     
    $cities=array();
    $client = new SoapClient("http://smsamobilepro.cloudapp.net/retailcenter.asmx?op=ListOfCities&wsdl");
      try {
        //Invoke WS method (Function1) with the request params
        $capitalresponse = $client->__soapCall("ListOfCities", array($tocapital));
      }
      catch(Throwable $e){
          echo 'sorry... our web service is down';
      }
      // echo "<pre>" ; print_r($capitalresponse->ListOfCitiesResult->CitiesRes);
      // if(count($capitalresponse->ListOfCitiesResult->CitiesRes, COUNT_RECURSIVE) == 1){
      //   echo 33;
      //   $resultArray =(array) $capitalresponse->ListOfCitiesResult->CitiesRes;
      //   $cities[] = $resultArray;

        /*$city_name =array();*/
      // } else {
        $result = json_decode(json_encode($capitalresponse), true);
        $cities = $result['ListOfCitiesResult']['CitiesRes'];
      // }
      //echo "<pre>" ; print_r($cities);exit;
      $capital='';
      if(count($cities, COUNT_RECURSIVE) != 1){
        foreach ($cities as $content) {
          $val=$content['Iscapital'];
            //
          if( $val == 'True'){
             $capital = $content['City'];
             break;
          }  
        }
      }
     // echo "<pre>" ; print_r($cities);exit();
      return $capital;
  }

  public function getCountries() {
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
    if($language == 'en'){
      $language = 'En';
    }
    if( $language == 'ar' ){
      $language = 'Ar';
    }
    $tocountries=[
       'passkey' => 'cl$ervice',
       'language' => (String) $language
    ];
     
    $cities=array();
    $client = new SoapClient("http://smsamobilepro.cloudapp.net/retailcenter.asmx?op=ListOfCountries&wsdl");
      try {
        //Invoke WS method (Function1) with the request params
        $countryresponse = $client->__soapCall("ListOfCountries", array($tocountries));
      }
      catch(Throwable $e){
          echo 'sorry... our web service is down';
      }
      //echo "<pre>" ; print_r($countryresponse);exit();
      // if(count($countryresponse->ListOfCountriesResult->countryRes, COUNT_RECURSIVE) == 1){
      //   $resultArray =(array) $countryresponse->ListOfCountriesResult->countryRes;
      //   $countries[] = $resultArray;
      //   /*$city_name =array();*/
      // }else {
        $result = json_decode(json_encode($countryresponse), true);
        $countries = $result['ListOfCountriesResult']['countryRes'];
      //}
        //echo "<pre>";print_r($countries);exit;
      $countryName = array();
      if(is_array($countries)){
        foreach ($countries as $content) {
        $val=$content['IsFrom'];
          //
        if( $val == 'True'){
           $countryName[$this->countryCodeToCountry($content['Ccode'])] = $content['Country'];
        }  
      }
      }
      return $countryName;
  }
  public function toCountries() {
        $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
        if($language == 'en'){
          $language = 'En';
        }
        if( $language == 'ar' ){
          $language = 'Ar';
        }
        $tocountries=[
           'passkey' => 'cl$ervice',
           'language' => (String) $language
        ];
         
        $cities=array();
        $client = new SoapClient("http://smsamobilepro.cloudapp.net/retailcenter.asmx?op=ListOfCountries&wsdl");
          try {
            //Invoke WS method (Function1) with the request params
            $countryresponse = $client->__soapCall("ListOfCountries", array($tocountries));
          }
          catch(Throwable $e){
              echo 'sorry... our web service is down';
          }
          //echo "<pre>" ; print_r($countryresponse);exit();
          if(count($countryresponse->ListOfCountriesResult->countryRes, COUNT_RECURSIVE) == 1){
            $resultArray =(array) $countryresponse->ListOfCountriesResult->countryRes;
            $countries[] = $resultArray;
            /*$city_name =array();*/
          }else {
            $result = json_decode(json_encode($countryresponse), true);
            $countries = $result['ListOfCountriesResult']['countryRes'];
          }

          $countryName = array();
          foreach ($countries as $content) {
            $val=$content['IsFrom'];
            //if( $val == 'True'){
               $countryName[$this->countryCodeToCountry($content['Ccode'])] = $content['Country'];
            //}  
          }
        return $countryName;
  }


  public function getCountryCodeAsDataAttr()
  {
    $country_codes = [];
    $countries = \Drupal\Core\Locale\CountryManager::getStandardList();
    foreach ($countries as $country_code => $country_display_name) {
      $country_name = str_replace(" ", "_", $country_display_name);
      $country_codes[$this->countryCodeToCountry($country_code)] = ['data-code' => $country_code];
    }
    return $country_codes;
  }
  public function findfromCityCallback(array $form, FormStateInterface $form_state) {
    $form['#attached']['library'][] = 'drupal.ajax';
    $ajax_response = new AjaxResponse();
    $selected_country = $form_state->getValue('from_country');
    $form['from_city'] = array(
      '#type' => 'select',
      '#title' => $this->t('From city'),
      '#empty_option' => t('Select City'),
       '#validated' => TRUE,
      '#options'=>  $this->apiRequestForfromcity($selected_country),
      '#prefix' => '<div id="edit-from-city">', '#suffix' => '</div>',
      '#required'=>false,
      '#default_value' => '',
      '#attributes' => array(
        'name' => 'from_city'
      ),
    );
    $ajax_response->addCommand(new ReplaceCommand("#edit-from-city", ($form['from_city'])));
    return $ajax_response;

    //return $form['from_city'];
  }
  public function findtoCityCallback(array $form, FormStateInterface $form_state) {
    $form['#attached']['library'][] = 'drupal.ajax';
    $ajax_response = new AjaxResponse();
    $selected_country = $form_state->getValue('to_country');
    $form['to_city'] = array(
      '#type' => 'select',
      '#validated' => TRUE,
      '#title' => $this->t('To city'),
      "#empty_option" => t('Select City'),
      '#options'=> $this->apiRequestFortocity($selected_country),
      '#prefix' => '<div id="edit-to-city">', '#suffix' => '</div>',
      '#required'=>false,
      '#default_value' => '',
      '#attributes' => array(
        'name' => 'to_city'
      ),
    );
    $ajax_response->addCommand(new ReplaceCommand("#edit-to-city", ($form['to_city'])));
    return $ajax_response;
    //return $form['to_city'];
  }
  
  public function apiRequestFortocity($country)
    { 
      // Initialize WS with the WSDL
      $tocityresponse='';
      $cities=array();
      if(strpos($country, '_') !== false){
          $fcountry = str_replace("_", " ", $country);
      } else{
          $fcountry = $country; 
      }
      $tocitydata=[
       'country'=>  $fcountry,
       'passkey' => 'rcc$ervice',
       'language' => 'En'
      ];
      $client = new SoapClient("http://smsamobilepro.cloudapp.net/retailcenter.asmx?op=ListOfCities&wsdl");
      try {
        //Invoke WS method (Function1) with the request params
        $tocityresponse = $client->__soapCall("ListOfCities", array($tocitydata));
      }
      catch(Throwable $e){
          echo 'sorry... our web service is down';
      }
      $to_city_list=array();
      if(isset($tocityresponse->ListOfCitiesResult->CitiesRes)){
        $result = json_decode(json_encode($tocityresponse), true);
        $cities = $result['ListOfCitiesResult']['CitiesRes'];
        foreach ($cities as $contentVal) {
          $to_city_list[$contentVal['City']] = $contentVal['City'];
        }
      }
      return $to_city_list;
    }
    public function apiRequestForfromcity($fromcountry)
    {
       
      // Initialize WS with the WSDL

      $fromcityresponse='';
      $from_cities=array();
      if(strpos($fromcountry, '_') !== false){
          $fcountryName = str_replace("_", " ", $fromcountry);
      } else{
          $fcountryName = $fromcountry; 
      }
      $fromcitydata=[
       'country'=> $fcountryName,
       'passkey' => 'rcc$ervice',
       'language' => 'En'
      ];
      $client = new SoapClient("http://smsamobilepro.cloudapp.net/retailcenter.asmx?op=ListOfCities&wsdl");
      try {
        //Invoke WS method (Function1) with the request params
        $fromcityresponse = $client->__soapCall("ListOfCities", array($fromcitydata));
      }
      catch(Throwable $e){
          echo 'sorry... our web service is down';
      }
      $from_city_list = array();
      if(isset($fromcityresponse->ListOfCitiesResult->CitiesRes)){
        $result = json_decode(json_encode($fromcityresponse), true);
        $from_cities = $result['ListOfCitiesResult']['CitiesRes'];

        $from_city_list=array();
        foreach ($from_cities as $content) {
          $from_city_list[$content['City']] = $content['City'];
        }
      }
      return $from_city_list;
    }
  function countryCodeToCountry($code) {
      $code = strtoupper($code);
      if ($code == 'AF') return 'Afghanistan';
      if ($code == 'AX') return 'Aland Islands';
      if ($code == 'AL') return 'Albania';
      if ($code == 'DZ') return 'Algeria';
      if ($code == 'AS') return 'American Samoa';
      if ($code == 'AD') return 'Andorra';
      if ($code == 'AO') return 'Angola';
      if ($code == 'AI') return 'Anguilla';
      if ($code == 'AQ') return 'Antarctica';
      if ($code == 'AG') return 'Antigua and Barbuda';
      if ($code == 'AR') return 'Argentina';
      if ($code == 'AM') return 'Armenia';
      if ($code == 'AW') return 'Aruba';
      if ($code == 'AU') return 'Australia';
      if ($code == 'AT') return 'Austria';
      if ($code == 'AZ') return 'Azerbaijan';
      if ($code == 'BS') return 'Bahamas the';
      if ($code == 'BH') return 'Bahrain';
      if ($code == 'BD') return 'Bangladesh';
      if ($code == 'BB') return 'Barbados';
      if ($code == 'BY') return 'Belarus';
      if ($code == 'BE') return 'Belgium';
      if ($code == 'BZ') return 'Belize';
      if ($code == 'BJ') return 'Benin';
      if ($code == 'BM') return 'Bermuda';
      if ($code == 'BT') return 'Bhutan';
      if ($code == 'BO') return 'Bolivia';
      if ($code == 'BA') return 'Bosnia and Herzegovina';
      if ($code == 'BW') return 'Botswana';
      if ($code == 'BV') return 'Bouvet Island (Bouvetoya)';
      if ($code == 'BR') return 'Brazil';
      if ($code == 'IO') return 'British Indian Ocean Territory (Chagos Archipelago)';
      if ($code == 'VG') return 'British Virgin Islands';
      if ($code == 'BN') return 'Brunei Darussalam';
      if ($code == 'BG') return 'Bulgaria';
      if ($code == 'BF') return 'Burkina Faso';
      if ($code == 'BI') return 'Burundi';
      if ($code == 'KH') return 'Cambodia';
      if ($code == 'CM') return 'Cameroon';
      if ($code == 'CA') return 'Canada';
      if ($code == 'CV') return 'Cape Verde';
      if ($code == 'KY') return 'Cayman Islands';
      if ($code == 'CF') return 'Central African Republic';
      if ($code == 'TD') return 'Chad';
      if ($code == 'CL') return 'Chile';
      if ($code == 'CN') return 'China';
      if ($code == 'CX') return 'Christmas Island';
      if ($code == 'CC') return 'Cocos (Keeling) Islands';
      if ($code == 'CO') return 'Colombia';
      if ($code == 'KM') return 'Comoros the';
      if ($code == 'CD') return 'Congo';
      if ($code == 'CG') return 'Congo the';
      if ($code == 'CK') return 'Cook Islands';
      if ($code == 'CR') return 'Costa Rica';
      if ($code == 'CI') return 'Cote d\'Ivoire';
      if ($code == 'HR') return 'Croatia';
      if ($code == 'CU') return 'Cuba';
      if ($code == 'CY') return 'Cyprus';
      if ($code == 'CZ') return 'Czech Republic';
      if ($code == 'DK') return 'Denmark';
      if ($code == 'DJ') return 'Djibouti';
      if ($code == 'DM') return 'Dominica';
      if ($code == 'DO') return 'Dominican Republic';
      if ($code == 'EC') return 'Ecuador';
      if ($code == 'EG') return 'Egypt';
      if ($code == 'SV') return 'El Salvador';
      if ($code == 'GQ') return 'Equatorial Guinea';
      if ($code == 'ER') return 'Eritrea';
      if ($code == 'EE') return 'Estonia';
      if ($code == 'ET') return 'Ethiopia';
      if ($code == 'FO') return 'Faroe Islands';
      if ($code == 'FK') return 'Falkland Islands (Malvinas)';
      if ($code == 'FJ') return 'Fiji the Fiji Islands';
      if ($code == 'FI') return 'Finland';
      if ($code == 'FR') return 'France, French Republic';
      if ($code == 'GF') return 'French Guiana';
      if ($code == 'PF') return 'French Polynesia';
      if ($code == 'TF') return 'French Southern Territories';
      if ($code == 'GA') return 'Gabon';
      if ($code == 'GM') return 'Gambia the';
      if ($code == 'GE') return 'Georgia';
      if ($code == 'DE') return 'Germany';
      if ($code == 'GH') return 'Ghana';
      if ($code == 'GI') return 'Gibraltar';
      if ($code == 'GR') return 'Greece';
      if ($code == 'GL') return 'Greenland';
      if ($code == 'GD') return 'Grenada';
      if ($code == 'GP') return 'Guadeloupe';
      if ($code == 'GU') return 'Guam';
      if ($code == 'GT') return 'Guatemala';
      if ($code == 'GG') return 'Guernsey';
      if ($code == 'GN') return 'Guinea';
      if ($code == 'GW') return 'Guinea-Bissau';
      if ($code == 'GY') return 'Guyana';
      if ($code == 'HT') return 'Haiti';
      if ($code == 'HM') return 'Heard Island and McDonald Islands';
      if ($code == 'VA') return 'Holy See (Vatican City State)';
      if ($code == 'HN') return 'Honduras';
      if ($code == 'HK') return 'Hong Kong';
      if ($code == 'HU') return 'Hungary';
      if ($code == 'IS') return 'Iceland';
      if ($code == 'IN') return 'India';
      if ($code == 'ID') return 'Indonesia';
      if ($code == 'IR') return 'Iran';
      if ($code == 'IQ') return 'Iraq';
      if ($code == 'IE') return 'Ireland';
      if ($code == 'IM') return 'Isle of Man';
      if ($code == 'IL') return 'Israel';
      if ($code == 'IT') return 'Italy';
      if ($code == 'JM') return 'Jamaica';
      if ($code == 'JP') return 'Japan';
      if ($code == 'JE') return 'Jersey';
      if ($code == 'JO') return 'Jordan';
      if ($code == 'KZ') return 'Kazakhstan';
      if ($code == 'KE') return 'Kenya';
      if ($code == 'KI') return 'Kiribati';
      if ($code == 'KP') return 'Korea';
      if ($code == 'KR') return 'Korea';
      if ($code == 'KW') return 'Kuwait';
      if ($code == 'KG') return 'Kyrgyz Republic';
      if ($code == 'LA') return 'Lao';
      if ($code == 'LV') return 'Latvia';
      if ($code == 'LB') return 'Lebanon';
      if ($code == 'LS') return 'Lesotho';
      if ($code == 'LR') return 'Liberia';
      if ($code == 'LY') return 'Libyan Arab Jamahiriya';
      if ($code == 'LI') return 'Liechtenstein';
      if ($code == 'LT') return 'Lithuania';
      if ($code == 'LU') return 'Luxembourg';
      if ($code == 'MO') return 'Macao';
      if ($code == 'MK') return 'Macedonia';
      if ($code == 'MG') return 'Madagascar';
      if ($code == 'MW') return 'Malawi';
      if ($code == 'MY') return 'Malaysia';
      if ($code == 'MV') return 'Maldives';
      if ($code == 'ML') return 'Mali';
      if ($code == 'MT') return 'Malta';
      if ($code == 'MH') return 'Marshall Islands';
      if ($code == 'MQ') return 'Martinique';
      if ($code == 'MR') return 'Mauritania';
      if ($code == 'MU') return 'Mauritius';
      if ($code == 'YT') return 'Mayotte';
      if ($code == 'MX') return 'Mexico';
      if ($code == 'FM') return 'Micronesia';
      if ($code == 'MD') return 'Moldova';
      if ($code == 'MC') return 'Monaco';
      if ($code == 'MN') return 'Mongolia';
      if ($code == 'ME') return 'Montenegro';
      if ($code == 'MS') return 'Montserrat';
      if ($code == 'MA') return 'Morocco';
      if ($code == 'MZ') return 'Mozambique';
      if ($code == 'MM') return 'Myanmar';
      if ($code == 'NA') return 'Namibia';
      if ($code == 'NR') return 'Nauru';
      if ($code == 'NP') return 'Nepal';
      if ($code == 'AN') return 'Netherlands Antilles';
      if ($code == 'NL') return 'Netherlands the';
      if ($code == 'NC') return 'New Caledonia';
      if ($code == 'NZ') return 'New Zealand';
      if ($code == 'NI') return 'Nicaragua';
      if ($code == 'NE') return 'Niger';
      if ($code == 'NG') return 'Nigeria';
      if ($code == 'NU') return 'Niue';
      if ($code == 'NF') return 'Norfolk Island';
      if ($code == 'MP') return 'Northern Mariana Islands';
      if ($code == 'NO') return 'Norway';
      if ($code == 'OM') return 'Oman';
      if ($code == 'PK') return 'Pakistan';
      if ($code == 'PW') return 'Palau';
      if ($code == 'PS') return 'Palestinian Territory';
      if ($code == 'PA') return 'Panama';
      if ($code == 'PG') return 'Papua New Guinea';
      if ($code == 'PY') return 'Paraguay';
      if ($code == 'PE') return 'Peru';
      if ($code == 'PH') return 'Philippines';
      if ($code == 'PN') return 'Pitcairn Islands';
      if ($code == 'PL') return 'Poland';
      if ($code == 'PT') return 'Portugal, Portuguese Republic';
      if ($code == 'PR') return 'Puerto Rico';
      if ($code == 'QA') return 'Qatar';
      if ($code == 'RE') return 'Reunion';
      if ($code == 'RO') return 'Romania';
      if ($code == 'RU') return 'Russian Federation';
      if ($code == 'RW') return 'Rwanda';
      if ($code == 'BL') return 'Saint Barthelemy';
      if ($code == 'SH') return 'Saint Helena';
      if ($code == 'KN') return 'Saint Kitts and Nevis';
      if ($code == 'LC') return 'Saint Lucia';
      if ($code == 'MF') return 'Saint Martin';
      if ($code == 'PM') return 'Saint Pierre and Miquelon';
      if ($code == 'VC') return 'Saint Vincent and the Grenadines';
      if ($code == 'WS') return 'Samoa';
      if ($code == 'SM') return 'San Marino';
      if ($code == 'ST') return 'Sao Tome and Principe';
      if ($code == 'SA') return 'Saudi Arabia';
      if ($code == 'SN') return 'Senegal';
      if ($code == 'RS') return 'Serbia';
      if ($code == 'SC') return 'Seychelles';
      if ($code == 'SL') return 'Sierra Leone';
      if ($code == 'SG') return 'Singapore';
      if ($code == 'SK') return 'Slovakia (Slovak Republic)';
      if ($code == 'SI') return 'Slovenia';
      if ($code == 'SB') return 'Solomon Islands';
      if ($code == 'SO') return 'Somalia, Somali Republic';
      if ($code == 'ZA') return 'South Africa';
      if ($code == 'GS') return 'South Georgia and the South Sandwich Islands';
      if ($code == 'ES') return 'Spain';
      if ($code == 'LK') return 'Sri Lanka';
      if ($code == 'SD') return 'Sudan';
      if ($code == 'SR') return 'Suriname';
      if ($code == 'SJ') return 'Svalbard & Jan Mayen Islands';
      if ($code == 'SZ') return 'Swaziland';
      if ($code == 'SE') return 'Sweden';
      if ($code == 'CH') return 'Switzerland, Swiss Confederation';
      if ($code == 'SY') return 'Syrian Arab Republic';
      if ($code == 'TW') return 'Taiwan';
      if ($code == 'TJ') return 'Tajikistan';
      if ($code == 'TZ') return 'Tanzania';
      if ($code == 'TH') return 'Thailand';
      if ($code == 'TL') return 'Timor-Leste';
      if ($code == 'TG') return 'Togo';
      if ($code == 'TK') return 'Tokelau';
      if ($code == 'TO') return 'Tonga';
      if ($code == 'TT') return 'Trinidad and Tobago';
      if ($code == 'TN') return 'Tunisia';
      if ($code == 'TR') return 'Turkey';
      if ($code == 'TM') return 'Turkmenistan';
      if ($code == 'TC') return 'Turks and Caicos Islands';
      if ($code == 'TV') return 'Tuvalu';
      if ($code == 'UG') return 'Uganda';
      if ($code == 'UA') return 'Ukraine';
      if ($code == 'AE') return 'United Arab Emirates';
      if ($code == 'GB') return 'United Kingdom';
      if ($code == 'US') return 'United States of America';
      if ($code == 'UM') return 'United States Minor Outlying Islands';
      if ($code == 'VI') return 'United States Virgin Islands';
      if ($code == 'UY') return 'Uruguay, Eastern Republic of';
      if ($code == 'UZ') return 'Uzbekistan';
      if ($code == 'VU') return 'Vanuatu';
      if ($code == 'VE') return 'Venezuela';
      if ($code == 'VN') return 'Vietnam';
      if ($code == 'WF') return 'Wallis and Futuna';
      if ($code == 'EH') return 'Western Sahara';
      if ($code == 'YE') return 'Yemen';
      if ($code == 'XK') return 'Kosovo';
      if ($code == 'ZM') return 'Zambia';
      if ($code == 'ZW') return 'Zimbabwe';
      return '';
}
}
