<?php

namespace Drupal\smsa_api\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a shipping rate enquiry block.
 *
 * @Block(
 *   id = "shipping_rate_enquiry",
 *   admin_label = @Translation("Shipping Rate Enquiry"),
 * )
 */
class ShippingRate extends BlockBase {
  public function build() {
    return \Drupal::formBuilder()->getForm('Drupal\smsa_api\Form\ShippingRateEnquiryForm');
  }
}
