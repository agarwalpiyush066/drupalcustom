<?php

namespace Drupal\smsa_api\Controller;

use Drupal\Core\Controller\ControllerBase;
use SoapClient;
use Throwable;

class RateController extends ControllerBase
{
  public function rateCalculate()
  {
    $weight =  \Drupal::request()->query->get('weight');
    $weight_type =  \Drupal::request()->query->get('weight_type');
    if( $weight_type == 'lbs' ){
      $weight = $weight*0.4535;
    }
    
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $country_form = \Drupal::formBuilder()->getForm('Drupal\smsa_api\Form\ShippingRateEnquiryMainForm');
    $fromc=\Drupal::request()->query->get('fcountry');
    //$f_country = str_replace(" ", "_", $fromc);
    $to_country = \Drupal::request()->query->get('tcountry');
    //$t_country = str_replace(" ", "_", $country_name); 
    $to_city= \Drupal::request()->query->get('tcity');
    $from_city= \Drupal::request()->query->get('fcity');

    $data = [
      'fromCountry' =>$fromc,
      'toCountry' => $to_country,
      'documents' => 'Parcel',
      'toCity'=>$to_city,
      'fromCity'=>$from_city,
      'productcategory' => 'Parcel',
      'passkey' => 'ri$ervice',
      'weight' => $weight,
      'language' => ucfirst($language)
    ];
	$response = array();
	if($data['fromCountry'] && $data['toCountry']){
	    $response = $this->apiRequest($data);
	}


    $content = array();
    if( !empty( $response )){
      $result = json_decode(json_encode($response), true);
      $content = $result['RateInquiryResult']['RIRes'];
    }
	
    $keys = array_column($content, 'Totalamount');
    array_multisort($keys, SORT_ASC, $content);
    $weightValue = '';
    if(isset( $_GET['weight'] ) && $_GET['weight'] != "" ){
      $weightValue = $_GET['weight'];
    }
    $template = [
      '#theme' => 'rate_api',
      '#data' => $content,
      '#weight_value' => $weightValue,
      '#countryform' => $country_form,
      '#weight' => $weight,
      '#attached' => array(
      'library' => array('smsa_api/rate'),
      )
    ];
    return $template;
  }

  public function apiRequest($data)
  {
    // Initialize WS with the WSDL
    $client = new SoapClient("http://smsamobileappwebservicepro.cloudapp.net/MobileAppService.asmx?wsdl");
    try {
      //Invoke WS method (Function1) with the request params
      $response = $client->__soapCall("RateInquiry", array($data));
    }
    catch(Throwable $e){
	$response = array();
        //print('sorry... our web service is down');
      }
    return $response;
  }

}
