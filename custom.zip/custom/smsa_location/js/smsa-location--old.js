(function($, Drupal, drupalSettings) {
  Drupal.behaviors.yourbehavior = {
    attach: function(context, settings) {
      $(document).ready(function() {
        var current_path = window.location.pathname;
        var selected_city = drupalSettings.selected_city;

        // var selected_region = drupalSettings.selected_region;
        //if (current_path === '/smsa/web/map-location') {
        $('.map-location-content .map-view a').addClass('active show');
        var locations = [];

        var markers = null;
        $.ajax({
          url: Drupal.url('fetch-center-latlong'),
          type: "POST",
          dataType: 'json',
          data: {
            'city': selected_city
          },
          success: function(response) {
            // debugger;
            var locations = response.langlong;
            //console.log(locations);
            setTimeout(function() {
              //console.log(response.retail_center_data);
              document.getElementById('secondtab').innerHTML = response.retail_center_data;
              document.getElementById('firsttab').innerHTML = '<div id="map" class="location - map" style="width: 100 %; height: 600px"></div>';
              $('#firsttab').addClass("active show");
              $('#secondtab').removeClass("active show");
              $('.map-view').addClass("active show");
              $('.list-view').removeClass("active show");
              var map = L.map('map', {
                center: [51.505, -0.09],
                zoom: 13
              });
              L.tileLayer(
                'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                  attribution: '',
                  maxZoom: 5,
                }).addTo(map);
              if (locations !== null) {
                for (var i = 0; i < locations.length; i++) {
                  marker = new L.marker([locations[i][1], locations[i][2]])
                    .bindPopup(locations[i][0])
                    .addTo(map);
                }
              }

              //locate();
              map.locate();
              centerLeafletMapOnMarker(map, marker);
              //map.locate({ setView: true, maxZoom: 16, enableHighAccuracy: true });
              map.on('locationfound', onLocationFound);
              map.on('locationerror', onLocationError);
            }, 500);
          }
        });

        // }

        // placeholders for the L.marker and L.circle representing user's current position and accuracy
        var current_position, current_accuracy;

        function onLocationFound(e) {

          showPosition(e.latlng.lat, e.latlng.lng);
          //alert(123);
          //showCurrentLocationOnMap(e.latlng, e.accuracy)
        }

        function showCurrentLocationOnMap(location, accuracy) {
          // if position defined, then remove the existing position marker and accuracy circle from the map
          if (current_position) {
            map.removeLayer(current_position);
            map.removeLayer(current_accuracy);
          }

          var radius = accuracy / 2;

          current_position = L.marker(location).addTo(map)
            .bindPopup("You are within " + radius + " meters from this point").openPopup();

          current_accuracy = L.circle(location, radius).addTo(map);

        }

        function onLocationError(e) {
          $.get("https://location.services.mozilla.com/v1/geolocate?key=test", function(r) {
            if (r !== undefined || r !== '') {
              showPosition(r.location.lat, r.location.lng);
              //showCurrentLocationOnMap(r.location, r.accuracy)
            }
          });
          //console.log(e.message);
        }


        // wrap map.locate in a function
        function locate() {
          map.locate({ setView: true, maxZoom: 16, enableHighAccuracy: true });
        }

        // call locate every 3 seconds... forever
        //setInterval(locate, 3000);
        // map.on('load', function (ev) {
        //    alert(ev.latlng); // ev is an event object (MouseEvent in this case)
        //});

        function centerLeafletMapOnMarker(map, marker) {
          var latLngs = [marker.getLatLng()];
          var markerBounds = L.latLngBounds(latLngs);
          map.fitBounds(markerBounds);
        }

        function showPosition(position_lat, position_lng) {
          //alert(123456);
          //var lat_from = position.coords.latitude;
          //var long_from = position.coords.longitude;
          var lat_from = position_lat;
          var long_from = position_lng;
          if (typeof drupalSettings.selected_city !== "undefined") {
            var selected_city = drupalSettings.selected_city;
          } else {
            var selected_city = '';
          }
          $.ajax({
            url: Drupal.url('calc_distance'),
            type: "POST",
            dataType: 'json',
            data: {
              'lat_from': lat_from,
              'long_from': long_from,
              'city': selected_city
            },
            success: function(response) {
              if (response.distance) {
                //alert(response.distance);
                $.each(response.distance, function(key, value) {
                  $("#center-distance-" + key).text(value);
                });
              }
            }
          });
        }
      });
    }
  };
})(jQuery, Drupal, drupalSettings);