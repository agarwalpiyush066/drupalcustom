(function($, Drupal, drupalSettings) {
  Drupal.behaviors.yourbehavior = {
    attach: function(context, settings) {

      function checkCitiesHasValue(){
        if($('.get-cities .filter-option .filter-option-inner-inner').text() == 'Nothing selected'){
          jQuery('.show-centers-msg').show();
          jQuery('.map-location-content').hide();
        }else{
          jQuery('.map-location-content').show();
          jQuery('.show-centers-msg').hide();
        }
      }

      $( document ).ajaxComplete(function() {
        checkCitiesHasValue();
      });

    /*jQuery('.location-filter-form .form-item-country  select').on('change', function(){
        if(jQuery(this).val() == "Saudi Arabia"){
          jQuery('.map-location-content').show();
          jQuery('.show-centers-msg').hide();
        }else{
          jQuery('.map-location-content').hide();
          jQuery('.show-centers-msg').show();
        }
    });*/
    jQuery('.get-cities  select').on('change', function(){
        jQuery('#edit-find').trigger('click');
        jQuery('.map-location-content').show();
    });
    jQuery('#edit-find').bind('click',function(){
        jQuery('.map-location-content').show();
    });    
    $('#cities-list').selectpicker('refresh');
    var userAgent = window.navigator.userAgent;
    if(userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)){
    }else{
        var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));  
        if(isSafari != true){
            navigator.permissions.query({name:'geolocation'}).then(function(result) {
            // Will return ['granted', 'prompt', 'denied']
              
                  if( result.state == 'granted' || result.state == 'prompt'  ){
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function(position) {
                            var latx = position.coords.latitude;    
                            var lonx = position.coords.longitude;
                            jQuery('#secondtab').attr('current-lat', latx);
                            jQuery('#secondtab').attr('current-long', lonx);
                            var current_path = window.location.pathname;
                            var selected_city = drupalSettings.selected_city;
                            var selected_country = drupalSettings.selected_country;
                            // var selected_region = drupalSettings.selected_region;
                            //if (current_path === '/smsa/web/map-location') {
                            $('.map-location-content .map-view a').addClass('active show');
                            var locations = [];

                            var markers = null;
                            $.ajax({
                              url: Drupal.url('fetch-center-latlong'),
                              type: "POST",
                              dataType: 'json',
                              data: {
                                'city': selected_city,
                                'c_lat' : jQuery('#secondtab').attr('current-lat'),
                                'c_long' : jQuery('#secondtab').attr('current-long'),
                                'country' : selected_country
                              },
                              success: function(response) {
                                // debugger;
                                var locations = response.langlong;

                                setTimeout(function() {
                                  document.getElementById('secondtab').innerHTML = response.retail_center_data;
                                  document.getElementById('firsttab').innerHTML = '<div id="map" class="location - map" style="width: 100 %; height: 600px"></div>';
                                  $('#firsttab').addClass("active show");
                                  $('#secondtab').removeClass("active show");
                                  $('.map-view').addClass("active show");
                                  $('.list-view').removeClass("active show"); 
                                    var map, infoWindow;
                                        /*f = navigator.userAgent.search("Firefox");
                                        if (f > -1) {
                                          mapDate();
                                        }*/
                                        // Try HTML5 geolocation.
                                        //f = navigator.userAgent.search("Firefox");
                                        //if (f > -1) {
                                         // mapDate();
                                        //}else{
                                            navigator.permissions.query({name:'geolocation'}).then(function(result) {
                                              // Will return ['granted', 'prompt', 'denied']
                                                if( result.state == 'granted' || result.state == 'prompt'  ){

                                                    if (navigator.geolocation) {
                                                        navigator.geolocation.getCurrentPosition(function(position) {
                                                            var latx = position.coords.latitude;    
                                                            var lonx = position.coords.longitude;
                                                            var geocoder = new google.maps.Geocoder;
                                                            latlng = {lat: parseFloat(position.coords.latitude), lng: parseFloat(position.coords.longitude)};
                                                            geocoder.geocode({'location': latlng}, function(results, status) {
                                                                if(results){
                                                                var myObj = results[0].address_components[2].long_name;
                                  document.getElementById('firsttab').setAttribute("city", myObj);                     
                                  document.getElementById('firsttab').setAttribute("latx", position.coords.latitude);                     
                                  document.getElementById('firsttab').setAttribute("lonx", position.coords.longitude);                     
                                                                }
                                                                if(status == google.maps.GeocoderStatus.OK) {
                                                                  var currentLocation = results[0]['formatted_address']
                                                                  document.getElementById('firsttab').setAttribute("current_address", currentLocation);                     
                                                                };
                                                            });
                                                          locations.push([document.getElementById('firsttab').getAttribute("city"), position.coords.latitude, position.coords.longitude])

                                                          if( typeof drupalSettings.selected_city !== "undefined" ){
                                  var nearesetCity = NearestCity(position.coords.latitude, position.coords.longitude, locations);
                                  locations.push(nearesetCity);
                                                            locations.reverse();
                                                            var map = new google.maps.Map(document.getElementById('map'), {
                                                              zoom: 14,
                                                              center: new google.maps.LatLng(locations[0][15], locations[0][16]),
                                                              mapTypeId: google.maps.MapTypeId.ROADMAP
                                                            });
                                                            var infowindow = new google.maps.InfoWindow();

                                                            var marker, i;
                                                            var image = {
                                                              url: jQuery('#get-module-path').val()+'/img/storepinselected@4x.png',
                                                            };
                                                            var current_location_img = {
                                                              url: jQuery('#get-module-path').val()+'/img/home_mappin-3x.png',
                                                            };

                                                            for (i = 0; i < locations.length; i++) {
                                                                //var newcordinates = new google.maps.LatLng(locations[i][1], locations[i][2]);
                                                                  if(locations[i][0] == jQuery('#firsttab').attr('city')){
                                                                    marker = new google.maps.Marker({
                                                                      position: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
                                                                      map: map,
                                                                      icon: current_location_img 
                                                                    });
                                                                  }else{
                                                                    marker = new google.maps.Marker({
                                                                      position: new google.maps.LatLng(locations[i][15], locations[i][16]),
                                                                      map: map,
                                                                      icon: image
                                                                    });
                                                                  }
                                                                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                                                return function() {

                                                                  if(locations[i][0] == jQuery('#firsttab').attr('city')){
                                                                    var storeName = locations[i][0],  
                                                                    center_address = locations[i][17];
                                                                    var center_address = center_address ? center_address : "";
                                                                    var infoContentStart = "<div class='info-window user-current-location'>";
                                                                    var infoContentEnd = "</div>"
                                                                    var storeDescription =  jQuery('#firsttab').attr('current_address');;                                                              
                                                                    infowindow.setContent(infoContentStart + "<span class='user-current-address'>"+storeDescription+"</span>" + infoContentEnd);
                                                                    infowindow.open(map, marker);
                                                                  }else{                     
                                                                    if (window.location.href.indexOf("ar") > -1) {
                                                      var StoreLocationName = 'SMSA Express';
                                                      var openHours = 'توقيت المخرج';                                                                  
                                                    }else{
                                                      var StoreLocationName = 'SMSA Express';
                                                      var openHours = 'Outlet Timings';                                                                  
                                                    }
                                                                    var storeName = locations[i][0]; 
                                        var sun_morning_shift = locations[i][1]; 
                                        var sun_evening_shift = locations[i][2];
                                        var mon_morning_shift = locations[i][3]; 
                                        var mon_evening_shift = locations[i][4];
                                        var tue_morning_shift = locations[i][5]; 
                                        var tue_evening_shift = locations[i][6];
                                        var wed_morning_shift = locations[i][7]; 
                                        var wed_evening_shift = locations[i][8];
                                        var thu_morning_shift = locations[i][9]; 
                                        var thu_evening_shift = locations[i][10];
                                        var fri_morning_shift = locations[i][11]; 
                                        var fri_evening_shift = locations[i][12];
                                        var sat_morning_shift = locations[i][13]; 
                                        var sat_evening_shift = locations[i][14];                                                                 
                                        var center_address = locations[i][17];
                                        var address_lat = locations[i][15];
                                        var address_long = locations[i][16];
                      
                                    weekdays(infowindow,storeName,StoreLocationName,openHours,
                                                        sun_morning_shift,sun_evening_shift,
                                                        mon_morning_shift,mon_evening_shift,
                                                        tue_morning_shift,tue_evening_shift,
                                                        wed_morning_shift,wed_evening_shift,
                                                        thu_morning_shift,thu_evening_shift,
                                                        fri_morning_shift,fri_evening_shift,
                                                        sat_morning_shift,sat_evening_shift,
                                                        center_address,address_lat,address_long);
                                                            infowindow.open(map, marker);
                                                                  }
                                                                }
                                                              })(marker, i));
                                                            }
                                                          }

                                                          if( typeof drupalSettings.selected_city == "undefined" ){

                                                              var map = new google.maps.Map(document.getElementById('map'), {
                                                                  zoom: 14,
                                                                  center: new google.maps.LatLng(latx, lonx),
                                                                  mapTypeId: google.maps.MapTypeId.ROADMAP
                                                              });
                                                              var infowindow = new google.maps.InfoWindow();

                                                              var marker, i;
                                                              var image = {
                                                                url: jQuery('#get-module-path').val()+'/img/storepinselected@4x.png',
                                                              };
                                                              var current_location_img = {
                                                                url: jQuery('#get-module-path').val()+'/img/home_mappin-3x.png',
                                                              };

                                                              for (i = 0; i < locations.length; i++) {
                                                                  var newcordinates = new google.maps.LatLng(locations[i][15], locations[i][16]);
                                                                    if(locations[i][0] == document.getElementById('firsttab').getAttribute("city")){
                                                                      marker = new google.maps.Marker({
                                                                        position: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
                                                                        map: map,
                                                                        icon: current_location_img
                                                                      });
                                                                    }else{
                                                                      marker = new google.maps.Marker({
                                                                        position: new google.maps.LatLng(locations[i][15], locations[i][16]),
                                                                        map: map,
                                                                        icon: image
                                                                      });
                                                                    }
                                                                    if( typeof drupalSettings.selected_city !== "undefined" ){
                                                                      marker.setPosition(newcordinates);
                                                                      map.setCenter(newcordinates);
                                                                    }
                                                                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                                                  return function() {
                                                                    if(locations[i][0] == jQuery('#firsttab').attr('city')){
                                                                    var storeName = locations[i][0]; 
                                                                    var center_address = locations[i][17];
                                                                    var center_address = center_address ? center_address : "";
                                                                    var infoContentStart = "<div class='info-window user-current-location'>";
                                                                    var infoContentEnd = "</div>"
                                                                    var storeDescription =  jQuery('#firsttab').attr('current_address');;                                                              
                                                                    infowindow.setContent(infoContentStart + "<span class='user-current-address'>"+storeDescription+"</span>" + infoContentEnd);
                                                                    infowindow.open(map, marker);
                                                                  }else{
                                                                    jQuery(".info-window").attr("current_lat", locations[i][15]);                     
                                                                    jQuery(".info-window").attr("current_long",locations[i][16]);
                                                                    if (window.location.href.indexOf("ar") > -1) {
                                                      var StoreLocationName = 'SMSA Express';
                                                      var openHours = 'توقيت المخرج';                                                                  
                                                    }else{
                                                      var StoreLocationName = 'SMSA Express';
                                                      var openHours = 'Outlet Timings';                                                                  
                                                    }
                                                                    var storeName = locations[i][0]; 
                                        var sun_morning_shift = locations[i][1]; 
                                        var sun_evening_shift = locations[i][2];
                                        var mon_morning_shift = locations[i][3]; 
                                        var mon_evening_shift = locations[i][4];
                                        var tue_morning_shift = locations[i][5]; 
                                        var tue_evening_shift = locations[i][6];
                                        var wed_morning_shift = locations[i][7]; 
                                        var wed_evening_shift = locations[i][8];
                                        var thu_morning_shift = locations[i][9]; 
                                        var thu_evening_shift = locations[i][10];
                                        var fri_morning_shift = locations[i][11]; 
                                        var fri_evening_shift = locations[i][12];
                                        var sat_morning_shift = locations[i][13]; 
                                        var sat_evening_shift = locations[i][14];                                                                 
                                        var center_address = locations[i][17];
                                        var address_lat = locations[i][15];
                                        var address_long = locations[i][16];  
                                                              weekdays(infowindow,storeName,StoreLocationName,openHours,
                                                                sun_morning_shift,sun_evening_shift,
                                                                mon_morning_shift,mon_evening_shift,
                                                                tue_morning_shift,tue_evening_shift,
                                                                wed_morning_shift,wed_evening_shift,
                                                                thu_morning_shift,thu_evening_shift,
                                                                fri_morning_shift,fri_evening_shift,
                                                                sat_morning_shift,sat_evening_shift,
                                                                center_address,address_lat,address_long); 
                                                                  infowindow.open(map, marker);
                                                                  }
     
                                                                  }
                                                                })(marker, i));
                                                              }
                                                          }
                                                            
                                                        }, function() {
                                                          f = navigator.userAgent.search("Firefox");
                                                          if (f > -1) {
                                                            mapDate();
                                                          }
                                                        //handleLocationError(true, infoWindow, map.getCenter());
                                                      });
                                                    }else {
                                                        
                                                    }
                                                }else if( result.state == 'denied' || result.state == 'prompt' ){
                                                     mapDate();   
                                                }

                                            });       
                                        //} 
                                        function mapDate(){
                                            var map = new google.maps.Map(document.getElementById('map'), {
                                                zoom: 12,
                                                center: new google.maps.LatLng(24.774265, 46.738586),
                                                mapTypeId: google.maps.MapTypeId.ROADMAP
                                            });
                                            var infowindow = new google.maps.InfoWindow();
                                            var marker, i;
                                            var image = {
                                              url: jQuery('#get-module-path').val()+'/img/storepinselected@4x.png',
                                                // This marker is 20 pixels wide by 32 pixels high.
                                                //size: new google.maps.Size(20, 32),
                                            }; 
                                            for (i = 0; i < locations.length; i++) {
                                                var newcordinates = new google.maps.LatLng(locations[i][15], locations[i][16]);
                                                    marker = new google.maps.Marker({
                                                    position: new google.maps.LatLng(locations[i][15], locations[i][16]),
                                                    map: map,
                                                    icon: image
                                                });
                                                if( typeof drupalSettings.selected_city !== "undefined" ){
                                                    marker.setPosition(newcordinates);
                                                    map.setCenter(newcordinates);
                                                }
                                              google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                                return function() {
                                                  if (window.location.href.indexOf("ar") > -1) {
                                            var StoreLocationName = 'SMSA Express';
                                            var openHours = 'توقيت المخرج';                                                                  
                                          }else{
                                            var StoreLocationName = 'SMSA Express';
                                            var openHours = 'Outlet Timings';                                                                  
                                          }
                                                    var storeName = locations[i][0]; 
                                var sun_morning_shift = locations[i][1]; 
                                var sun_evening_shift = locations[i][2];
                                var mon_morning_shift = locations[i][3]; 
                                var mon_evening_shift = locations[i][4];
                                var tue_morning_shift = locations[i][5]; 
                                var tue_evening_shift = locations[i][6];
                                var wed_morning_shift = locations[i][7]; 
                                var wed_evening_shift = locations[i][8];
                                var thu_morning_shift = locations[i][9]; 
                                var thu_evening_shift = locations[i][10];
                                var fri_morning_shift = locations[i][11]; 
                                var fri_evening_shift = locations[i][12];
                                var sat_morning_shift = locations[i][13]; 
                                var sat_evening_shift = locations[i][14];                                                                 
                                var center_address = locations[i][17];
                              var address_lat = locations[i][15];
                            var address_long = locations[i][16];  
                            weekdays(infowindow,storeName,StoreLocationName,openHours,
                                                sun_morning_shift,sun_evening_shift,
                                                mon_morning_shift,mon_evening_shift,
                                                tue_morning_shift,tue_evening_shift,
                                                wed_morning_shift,wed_evening_shift,
                                                thu_morning_shift,thu_evening_shift,
                                                fri_morning_shift,fri_evening_shift,
                                                sat_morning_shift,sat_evening_shift,
                                                center_address,address_lat,address_long);
                                                  infowindow.open(map, marker);
                                                }
                                              })(marker, i));
                                            }
                                        }

                                }, 500);
                              }
                            });

                        }, function() {

                        });
                    }
                  }else if( result.state == 'denied'  ){ 
                            var latx = '';    
                            var lonx = '';    
                      jQuery('#secondtab').attr('current-lat', latx);
                      jQuery('#secondtab').attr('current-long', lonx);

                  }
            });
        }
    }
    $(document).ready(function() {
        checkCitiesHasValue();
        var current_path = window.location.pathname;
        var selected_city = drupalSettings.selected_city;
        var selected_country = drupalSettings.selected_country;
        $('.map-location-content .map-view a').addClass('active show');
        var locations = [];

        var markers = null;
        $.ajax({
          url: Drupal.url('fetch-center-latlong'),
          type: "POST",
          dataType: 'json',
          data: {
            'city': selected_city,
            'c_lat' : jQuery('#secondtab').attr('current-lat'),
            'c_long' : jQuery('#secondtab').attr('current-long'),
            'country' : selected_country
          },
          success: function(response) {
            // debugger;
            var locations = response.langlong;
            setTimeout(function() {
              
              document.getElementById('secondtab').innerHTML = response.retail_center_data;
              document.getElementById('firsttab').innerHTML = '<div id="map" class="location - map" style="width: 100 %; height: 600px"></div>';
              $('#firsttab').addClass("active show");
              $('#secondtab').removeClass("active show");
              $('.map-view').addClass("active show");
              $('.list-view').removeClass("active show");
            
                var map, infoWindow;

                    // Try HTML5 geolocation.
                    //f = navigator.userAgent.search("Firefox");
                    //if (f > -1) {
                      //mapDate();
                    //}else{
                    var userAgent = window.navigator.userAgent;
                    if(userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)){
                            var map = new google.maps.Map(document.getElementById('map'), {
                                zoom: 12,
                                center: new google.maps.LatLng(24.774265, 46.738586),
                                mapTypeId: google.maps.MapTypeId.ROADMAP
                            });
                            var infowindow = new google.maps.InfoWindow();
                            var marker, i;
                            var image = {
                              url: jQuery('#get-module-path').val()+'/img/storepinselected@4x.png',
                                // This marker is 20 pixels wide by 32 pixels high.
                                //size: new google.maps.Size(20, 32),
                            }; 
                            for (i = 0; i < locations.length; i++) {
                                var newcordinates = new google.maps.LatLng(locations[i][15], locations[i][16]);
                                    marker = new google.maps.Marker({
                                    position: new google.maps.LatLng(locations[i][15], locations[i][16]),
                                    map: map,
                                    icon: image
                                });
                                if( typeof drupalSettings.selected_city !== "undefined" ){
                                    marker.setPosition(newcordinates);
                                    map.setCenter(newcordinates);
                                }
                              google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                return function() {
                                  if (window.location.href.indexOf("ar") > -1) {
                                    var StoreLocationName = 'SMSA Express';
                                    var openHours = 'توقيت المخرج';                                                                  
                                  }else{
                                    var StoreLocationName = 'SMSA Express';
                                    var openHours = 'Outlet Timings';                                                                  
                                  }
                                    var storeName = locations[i][0]; 
                                    var sun_morning_shift = locations[i][1]; 
                                    var sun_evening_shift = locations[i][2];
                                    var mon_morning_shift = locations[i][3]; 
                                    var mon_evening_shift = locations[i][4];
                                    var tue_morning_shift = locations[i][5]; 
                                    var tue_evening_shift = locations[i][6];
                                    var wed_morning_shift = locations[i][7]; 
                                    var wed_evening_shift = locations[i][8];
                                    var thu_morning_shift = locations[i][9]; 
                                    var thu_evening_shift = locations[i][10];
                                    var fri_morning_shift = locations[i][11]; 
                                    var fri_evening_shift = locations[i][12];
                                    var sat_morning_shift = locations[i][13]; 
                                    var sat_evening_shift = locations[i][14];                                                                 
                                    var center_address = locations[i][17];
                                    var address_lat = locations[i][15];
                                    var address_long = locations[i][16];
                                    weekdays(infowindow,storeName,StoreLocationName,openHours,
                                      sun_morning_shift,sun_evening_shift,
                                      mon_morning_shift,mon_evening_shift,
                                      tue_morning_shift,tue_evening_shift,
                                      wed_morning_shift,wed_evening_shift,
                                      thu_morning_shift,thu_evening_shift,
                                      fri_morning_shift,fri_evening_shift,
                                      sat_morning_shift,sat_evening_shift,
                                      center_address,address_lat,address_long);
                                          infowindow.open(map, marker); 
                                }
                              })(marker, i));
                            }
                                      
                    }else{
                    var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));  
                    if(isSafari == true){
                            var map = new google.maps.Map(document.getElementById('map'), {
                                zoom: 12,
                                center: new google.maps.LatLng(24.774265, 46.738586),
                                mapTypeId: google.maps.MapTypeId.ROADMAP
                            });
                            var infowindow = new google.maps.InfoWindow();
                            var marker, i;
                            var image = {
                              url: jQuery('#get-module-path').val()+'/img/storepinselected@4x.png',
                                // This marker is 20 pixels wide by 32 pixels high.
                                //size: new google.maps.Size(20, 32),
                            }; 
                            for (i = 0; i < locations.length; i++) {
                                var newcordinates = new google.maps.LatLng(locations[i][15], locations[i][16]);
                                    marker = new google.maps.Marker({
                                    position: new google.maps.LatLng(locations[i][15], locations[i][16]),
                                    map: map,
                                    icon: image
                                });
                                if( typeof drupalSettings.selected_city !== "undefined" ){
                                    marker.setPosition(newcordinates);
                                    map.setCenter(newcordinates);
                                }
                              google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                return function() {
                                  if (window.location.href.indexOf("ar") > -1) {
                                    var StoreLocationName = 'SMSA Express';
                                    var openHours = 'توقيت المخرج';                                                                  
                                  }else{
                                    var StoreLocationName = 'SMSA Express';
                                    var openHours = 'Outlet Timings';                                                                  
                                  }
                                    var storeName = locations[i][0]; 
                        var sun_morning_shift = locations[i][1]; 
                        var sun_evening_shift = locations[i][2];
                        var mon_morning_shift = locations[i][3]; 
                        var mon_evening_shift = locations[i][4];
                        var tue_morning_shift = locations[i][5]; 
                        var tue_evening_shift = locations[i][6];
                        var wed_morning_shift = locations[i][7]; 
                        var wed_evening_shift = locations[i][8];
                        var thu_morning_shift = locations[i][9]; 
                        var thu_evening_shift = locations[i][10];
                        var fri_morning_shift = locations[i][11]; 
                        var fri_evening_shift = locations[i][12];
                        var sat_morning_shift = locations[i][13]; 
                        var sat_evening_shift = locations[i][14];                                                                 
                        var center_address = locations[i][17];
                        var address_lat = locations[i][15];
                    var address_long = locations[i][16];
                    weekdays(infowindow,storeName,StoreLocationName,openHours,
                              sun_morning_shift,sun_evening_shift,
                              mon_morning_shift,mon_evening_shift,
                              tue_morning_shift,tue_evening_shift,
                              wed_morning_shift,wed_evening_shift,
                              thu_morning_shift,thu_evening_shift,
                              fri_morning_shift,fri_evening_shift,
                              sat_morning_shift,sat_evening_shift,
                              center_address,address_lat,address_long);
                                  infowindow.open(map, marker); 
                                }
                              })(marker, i));
                            }
                        

                          }else{
                        navigator.permissions.query({name:'geolocation'}).then(function(result) {
                          // Will return ['granted', 'prompt', 'denied']
                          
                            if( result.state == 'granted' || result.state == 'prompt'  ){

                                if (navigator.geolocation) {
                                      navigator.geolocation.getCurrentPosition(function(position) {
                                        var latx = position.coords.latitude;      
                                        var lonx = position.coords.longitude;  
                                        var geocoder = new google.maps.Geocoder;
                                        latlng = {lat: parseFloat(position.coords.latitude), lng: parseFloat(position.coords.longitude)};
                                        geocoder.geocode({'location': latlng}, function(results, status) {
                                            if(results){
                                              var myObj = results[0].address_components[2].long_name;
                                              document.getElementById('firsttab').setAttribute("city", myObj);                     
                                            }
                                            if(status == google.maps.GeocoderStatus.OK) {
                                              var currentLocation = results[0]['formatted_address']
                                              document.getElementById('firsttab').setAttribute("current_address", currentLocation);                     
                                            };
                                        });
                                        locations.push([document.getElementById('firsttab').getAttribute("city"), position.coords.latitude, position.coords.longitude])

                                        if( typeof drupalSettings.selected_city !== "undefined" ){
                                          var nearesetCity = NearestCity(position.coords.latitude, position.coords.longitude, locations);
                        locations.push(nearesetCity);
                                          locations.reverse();
                                          var map = new google.maps.Map(document.getElementById('map'), {
                                            zoom: 14,
                                            center: new google.maps.LatLng(locations[0][15], locations[0][16]),
                                            mapTypeId: google.maps.MapTypeId.ROADMAP
                                          });
                                          var infowindow = new google.maps.InfoWindow();

                                          var marker, i;
                                          var image = {
                                            url: jQuery('#get-module-path').val()+'/img/storepinselected@4x.png',
                                          };
                                          var current_location_img = {
                                            url: jQuery('#get-module-path').val()+'/img/home_mappin-3x.png',
                                          };
                                          for (i = 0; i < locations.length; i++) {
                                              //var newcordinates = new google.maps.LatLng(locations[i][1], locations[i][2]);
                                                if(locations[i][0] == jQuery('#firsttab').attr('city')){
                                                    marker = new google.maps.Marker({
                                                    position: new google.maps.LatLng(position.coords.latitude,position.coords.longitude),
                                                    map: map,
                                                    icon: current_location_img
                                                  });
                                                }else{
                                                  marker = new google.maps.Marker({
                                                    position: new google.maps.LatLng(locations[i][15], locations[i][16]),
                                                    map: map,
                                                    icon: image
                                                  });
                                                }
                                            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                              return function() {
                                                if(locations[i][0] == jQuery('#firsttab').attr('city')){
                                                  var storeName = locations[i][0],  
                                                  center_address = locations[i][17];
                                                  var center_address = center_address ? center_address : "";
                                                  var infoContentStart = "<div class='info-window user-current-location'>";
                                                  var infoContentEnd = "</div>"
                                                  var storeDescription =  jQuery('#firsttab').attr('current_address');                                                              
                                                  infowindow.setContent(infoContentStart + "<span class='user-current-address'>"+storeDescription+"</span>" + infoContentEnd);
                                                  infowindow.open(map, marker);
                                                }else{
                                                  if (window.location.href.indexOf("ar") > -1) {
                                          var StoreLocationName = 'SMSA Express';
                                          var openHours = 'توقيت المخرج';                                                                  
                                        }else{
                                          var StoreLocationName = 'SMSA Express';
                                          var openHours = 'Outlet Timings';                                                                  
                                        }
                                                    var storeName = locations[i][0]; 
                              var sun_morning_shift = locations[i][1]; 
                              var sun_evening_shift = locations[i][2];
                              var mon_morning_shift = locations[i][3]; 
                              var mon_evening_shift = locations[i][4];
                              var tue_morning_shift = locations[i][5]; 
                              var tue_evening_shift = locations[i][6];
                              var wed_morning_shift = locations[i][7]; 
                              var wed_evening_shift = locations[i][8];
                              var thu_morning_shift = locations[i][9]; 
                              var thu_evening_shift = locations[i][10];
                              var fri_morning_shift = locations[i][11]; 
                              var fri_evening_shift = locations[i][12];
                              var sat_morning_shift = locations[i][13]; 
                              var sat_evening_shift = locations[i][14];                                                                 
                              var center_address = locations[i][17];
                            var address_lat = locations[i][15];
                          var address_long = locations[i][16];
                          weekdays(infowindow,storeName,StoreLocationName,openHours,
                                                sun_morning_shift,sun_evening_shift,
                                                mon_morning_shift,mon_evening_shift,
                                                tue_morning_shift,tue_evening_shift,
                                                wed_morning_shift,wed_evening_shift,
                                                thu_morning_shift,thu_evening_shift,
                                                fri_morning_shift,fri_evening_shift,
                                                sat_morning_shift,sat_evening_shift,
                                                center_address,address_lat,address_long);
                                                  infowindow.open(map, marker);
                                                }
                                              }
                                            })(marker, i));
                                          }
                                        }

                                        if( typeof drupalSettings.selected_city == "undefined" ){

                                            var map = new google.maps.Map(document.getElementById('map'), {
                                                zoom: 14,
                                                center: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
                                                mapTypeId: google.maps.MapTypeId.ROADMAP
                                            });
                                            var infowindow = new google.maps.InfoWindow();

                                            var marker, i;
                                            var image = {
                                              url: jQuery('#get-module-path').val()+'/img/storepinselected@4x.png',
                                            };
                                            var current_location_img = {
                                              url: jQuery('#get-module-path').val()+'/img/home_mappin-3x.png',
                                            };
                                            for (i = 0; i < locations.length; i++) {
                                                var newcordinates = new google.maps.LatLng(locations[i][15], locations[i][16]);
                                                  if(locations[i][0] == document.getElementById('firsttab').getAttribute("city")){
                                                    marker = new google.maps.Marker({
                                                      position: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
                                                      map: map,
                                                      icon: current_location_img
                                                    });
                                                  }else{
                                                    marker = new google.maps.Marker({
                                                      position: new google.maps.LatLng(locations[i][15], locations[i][16]),
                                                      map: map,
                                                      icon: image
                                                    });
                                                  }
                                                  if( typeof drupalSettings.selected_city !== "undefined" ){
                                                    marker.setPosition(newcordinates);
                                                    map.setCenter(newcordinates);
                                                  }
                                              google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                                return function() {
                                                  if(locations[i][0] == jQuery('#firsttab').attr('city')){
                                                    var storeName = locations[i][0],  
                                                    center_address = locations[i][5];
                                                    var center_address = center_address ? center_address : "";
                                                    var infoContentStart = "<div class='info-window user-current-location'>";
                                                    var infoContentEnd = "</div>"
                                                    var storeDescription =  jQuery('#firsttab').attr('current_address');                                                              
                                                    infowindow.setContent(infoContentStart + "<span class='user-current-address'>"+storeDescription+"</span>" + infoContentEnd);
                                                    infowindow.open(map, marker);
                                                  }else{
                                                    if (window.location.href.indexOf("ar") > -1) {
                                            var StoreLocationName = 'SMSA Express';
                                            var openHours = 'توقيت المخرج';                                                                  
                                          }else{
                                            var StoreLocationName = 'SMSA Express';
                                            var openHours = 'Outlet Timings';                                                                  
                                          }
                                                    var storeName = locations[i][0]; 
                              var sun_morning_shift = locations[i][1]; 
                              var sun_evening_shift = locations[i][2];
                              var mon_morning_shift = locations[i][3]; 
                              var mon_evening_shift = locations[i][4];
                              var tue_morning_shift = locations[i][5]; 
                              var tue_evening_shift = locations[i][6];
                              var wed_morning_shift = locations[i][7]; 
                              var wed_evening_shift = locations[i][8];
                              var thu_morning_shift = locations[i][9]; 
                              var thu_evening_shift = locations[i][10];
                              var fri_morning_shift = locations[i][11]; 
                              var fri_evening_shift = locations[i][12];
                              var sat_morning_shift = locations[i][13]; 
                              var sat_evening_shift = locations[i][14];                                                                 
                              var center_address = locations[i][17];
                          var address_lat = locations[i][15];
                          var address_long = locations[i][16];
                          weekdays(infowindow,storeName,StoreLocationName,openHours,
                                                sun_morning_shift,sun_evening_shift,
                                                mon_morning_shift,mon_evening_shift,
                                                tue_morning_shift,tue_evening_shift,
                                                wed_morning_shift,wed_evening_shift,
                                                thu_morning_shift,thu_evening_shift,
                                                fri_morning_shift,fri_evening_shift,
                                                sat_morning_shift,sat_evening_shift,
                                                center_address,address_lat,address_long); 
                                                    infowindow.open(map, marker);
                                                  }

                                                }
                                              })(marker, i));
                                            }
                                        } 

                                    }, function() {
                                    //handleLocationError(true, infoWindow, map.getCenter());
                                    f = navigator.userAgent.search("Firefox");
                                    if (f > -1) {
                                      mapDate();
                                    }
                                  });
                                }else {
                                    
                                }
                            }else if( result.state == 'denied' || result.state == 'prompt' ){
                                 mapDate();   
                            }
                        });   
                      }
                }      
                    //} 
                    function mapDate(){
                        var map = new google.maps.Map(document.getElementById('map'), {
                            zoom: 12,
                            center: new google.maps.LatLng(24.774265, 46.738586),
                            mapTypeId: google.maps.MapTypeId.ROADMAP
                        });
                        var infowindow = new google.maps.InfoWindow();
                        var marker, i;
                        var image = {
                          url: jQuery('#get-module-path').val()+'/img/storepinselected@4x.png',
                            // This marker is 20 pixels wide by 32 pixels high.
                            //size: new google.maps.Size(20, 32),
                        }; 
                        for (i = 0; i < locations.length; i++) {
                            var newcordinates = new google.maps.LatLng(locations[i][15], locations[i][16]);
                                marker = new google.maps.Marker({
                                position: new google.maps.LatLng(locations[i][15], locations[i][16]),
                                map: map,
                                icon: image
                            });
                            if( typeof drupalSettings.selected_city !== "undefined" ){
                                marker.setPosition(newcordinates);
                                map.setCenter(newcordinates);
                            }
                          google.maps.event.addListener(marker, 'click', (function(marker, i) {
                            return function() {
                              if (window.location.href.indexOf("ar") > -1) {
                                var StoreLocationName = 'SMSA Express';
                                var openHours = 'توقيت المخرج';                                                                  
                              }else{
                                var StoreLocationName = 'SMSA Express';
                                var openHours = 'Outlet Timings';                                                                  
                              }
                                var storeName = locations[i][0]; 
                    var sun_morning_shift = locations[i][1]; 
                    var sun_evening_shift = locations[i][2];
                    var mon_morning_shift = locations[i][3]; 
                    var mon_evening_shift = locations[i][4];
                    var tue_morning_shift = locations[i][5]; 
                    var tue_evening_shift = locations[i][6];
                    var wed_morning_shift = locations[i][7]; 
                    var wed_evening_shift = locations[i][8];
                    var thu_morning_shift = locations[i][9]; 
                    var thu_evening_shift = locations[i][10];
                    var fri_morning_shift = locations[i][11]; 
                    var fri_evening_shift = locations[i][12];
                    var sat_morning_shift = locations[i][13]; 
                    var sat_evening_shift = locations[i][14];                                                                 
                    var center_address = locations[i][17];
                    var address_lat = locations[i][15];
                var address_long = locations[i][16];
                weekdays(infowindow,storeName,StoreLocationName,openHours,
                          sun_morning_shift,sun_evening_shift,
                          mon_morning_shift,mon_evening_shift,
                          tue_morning_shift,tue_evening_shift,
                          wed_morning_shift,wed_evening_shift,
                          thu_morning_shift,thu_evening_shift,
                          fri_morning_shift,fri_evening_shift,
                          sat_morning_shift,sat_evening_shift,
                          center_address,address_lat,address_long);
                              infowindow.open(map, marker); 
                            }
                          })(marker, i));
                        }
                    }      
            }, 500);
            var tableRowCount = jQuery('.loadmoredata_table tr').length;
            jQuery(".tab-content").on("click",".load_more", function(){ 
              var $rows = jQuery('.loadmoredata_table tr');
              var lastActiveIndex = $rows.filter('.active:last').index();
              $rows.filter(':lt(' + (lastActiveIndex + 10) + ')').addClass('active');
              if ($rows.filter(':hidden').length === 0){
                jQuery('.load_more').hide();
              }
            });

            jQuery(document).on("click","#view-more-time",function() {
            jQuery('.map-time-hour').show();
            jQuery('.map-time-hour').css('display','block');
            jQuery(this).hide();
            jQuery('#view-less-time').css('display','block');

        });

        jQuery(document).on("click","#view-less-time",function() {
            jQuery('.map-time-hour').css('display','none');
            jQuery(this).hide();
            jQuery('#view-more-time').css('display','block');
        });

        jQuery('.get-cities  select').on('change', function(){
            jQuery('#edit-find').trigger('click');
            jQuery('.map-location-content').show();
        });
        /*jQuery('.location-filter-form .form-item-country  select').on('change', function(){
            if(jQuery(this).val() == "Saudi Arabia"){
              jQuery('.map-location-content').show();
              jQuery('.show-centers-msg').hide();
            }else{
              jQuery('.map-location-content').hide();
              jQuery('.show-centers-msg').show();
            }
        });*/
        jQuery('#edit-find').bind('click',function(){
            jQuery('.map-location-content').show();
        });

      }
    });

      });
    }
  };
    function tConvert(time) {
        var time = time.split(':');
        if(time[0].length == 1){
          var time = '0'+time[0] + ':' + time[1];
        }else{
          var time = time[0] + ':' + time[1];
        }
        // Check correct time format and split into components
        time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];
        if (time.length > 1) { // If time format correct
          time = time.slice(1); // Remove full string match value 
          time[5] = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
          time[0] = +time[0] % 12 || 12; // Adjust hours
        }
        return time.join(''); // return adjusted time or original string
    }
    function Deg2Rad(deg) {
    return deg * Math.PI / 180;
  }
  
  function PythagorasEquirectangular(lat1, lon1, lat2, lon2) {
    lat1 = Deg2Rad(lat1);
    lat2 = Deg2Rad(lat2);
    lon1 = Deg2Rad(lon1);
    lon2 = Deg2Rad(lon2);
    var R = 6371; // km
    var x = (lon2 - lon1) * Math.cos((lat1 + lat2) / 2);
    var y = (lat2 - lat1);
    var d = Math.sqrt(x * x + y * y) * R;
    return d;
  }

  function NearestCity(latitude, longitude, locations) {
    var minDif = 99999;
    var closest;

    for (index = 0; index < locations.length; ++index) {
      var dif = PythagorasEquirectangular(latitude, longitude, locations[index][15], locations[index][16]);
      if (dif < minDif) {
        closest = index;
        minDif = dif;
      }
    }

    // echo the nearest city
    $locationClosest = locations[closest];

    return $locationClosest;
  }
 
  function weekdays(infowindow,storeName,StoreLocationName,openHours,
    sun_morning_shift,sun_evening_shift,
    mon_morning_shift,mon_evening_shift,
    tue_morning_shift,tue_evening_shift,
    wed_morning_shift,wed_evening_shift,
    thu_morning_shift,thu_evening_shift,
    fri_morning_shift,fri_evening_shift,
    sat_morning_shift,sat_evening_shift,
    center_address,address_lat,address_long){
    
        // Sunday
        var sarr1 = sun_morning_shift.split('-');
        var sarr2 = sun_evening_shift.split('-');
        if(sarr1[0] && sarr1[1] && sarr2[0] && sarr2[1]   ){
          var openHoursTimeS = tConvert(sarr1[0]) + " - " + tConvert(sarr1[1])+', '+tConvert(sarr2[0]) + " - " + tConvert(sarr2[1]);
          var sundayOpenHours = tConvert(sarr1[0]) + " - " + tConvert(sarr1[1])+', '+tConvert(sarr2[0]) + " - " + tConvert(sarr2[1]);
        }else if(sarr1[0] && sarr1[1] ||  sarr2[0] &&  sarr2[1] ){
          var morShift = tConvert(sarr1[0]) + " - " + tConvert(sarr1[1]);
          var eveShift = tConvert(sarr2[0]) + " - " + tConvert(sarr2[1]);
          if(morShift){
            var openHoursTimeS = morShift;
            var sundayOpenHours = morShift;
          }else if(eveShift){
            var openHoursTimeS = eveShift;
            var sundayOpenHours = eveShift;
          }
        }

        // Monday
        var marr1 = mon_morning_shift.split('-');
        var marr2 = mon_evening_shift.split('-');
        if(marr1[0] && marr2[1] && marr2[0] && marr2[1]   ){
          var openHoursTimeM = tConvert(marr1[0]) + " - " + tConvert(marr1[1])+', '+tConvert(marr2[0]) + " - " + tConvert(marr2[1]);
          var mondayOpenHours = tConvert(marr1[0]) + " - " + tConvert(marr1[1])+', '+tConvert(marr2[0]) + " - " + tConvert(marr2[1]);
        }else if(marr1[0] && marr1[1] ||  marr2[0] &&  marr2[1] ){
          var MmorShift = tConvert(marr1[0]) + " - " + tConvert(marr1[1]);
          var MeveShift = tConvert(marr2[0]) + " - " + tConvert(marr2[1]);
          if(MmorShift){
            var openHoursTimeM = MmorShift;
            var mondayOpenHours = MmorShift;
          }else if(MeveShift){
            var openHoursTimeM = MeveShift;
            var mondayOpenHours = MeveShift;
          }
        }

        // Tuesday
        var tarr1 = tue_morning_shift.split('-');
        var tarr2 = tue_evening_shift.split('-');
        if(tarr1[0] && tarr2[1] && tarr2[0] && tarr2[1]   ){
          var openHoursTimeT = tConvert(tarr1[0]) + " - " + tConvert(tarr1[1])+', '+tConvert(tarr2[0]) + " - " + tConvert(tarr2[1]);
          var tuesdayOpenHours = tConvert(tarr1[0]) + " - " + tConvert(tarr1[1])+', '+tConvert(tarr2[0]) + " - " + tConvert(tarr2[1]);
        }else if(tarr1[0] && tarr1[1] ||  tarr2[0] &&  tarr2[1] ){
          var TmorShift = tConvert(tarr1[0]) + " - " + tConvert(tarr1[1]);
          var TeveShift = tConvert(tarr2[0]) + " - " + tConvert(tarr2[1]);
          if(TmorShift){
            var openHoursTimeT = TmorShift;
            var tuesdayOpenHours = TmorShift;
          }else if(MeveShift){
            var openHoursTimeT = TeveShift;
            var tuesdayOpenHours = TeveShift;
          }
        }

        // Wednesday
        var warr1 = wed_morning_shift.split('-');
        var warr2 = wed_evening_shift.split('-');
        if(warr1[0] && warr2[1] && warr2[0] && warr2[1]   ){
          var openHoursTimeW = tConvert(warr1[0]) + " - " + tConvert(warr1[1])+', '+tConvert(warr2[0]) + " - " + tConvert(warr2[1]);
          var wednesdayOpenHours = tConvert(warr1[0]) + " - " + tConvert(warr1[1])+', '+tConvert(warr2[0]) + " - " + tConvert(warr2[1]);
        }else if(warr1[0] && warr1[1] ||  warr2[0] &&  warr2[1] ){
          var WmorShift = tConvert(warr1[0]) + " - " + tConvert(warr1[1]);
          var WeveShift = tConvert(warr2[0]) + " - " + tConvert(warr2[1]);
          if(WmorShift){
            var openHoursTimeW = WmorShift;
            var wednesdayOpenHours = WmorShift;
          }else if(MeveShift){
            var openHoursTimeW = WeveShift;
            var wednesdayOpenHours = WeveShift;
          }
        }

        // Thursday
        var tharr1 = thu_morning_shift.split('-');
        var tharr2 = thu_evening_shift.split('-');
        if(tharr1[0] && tharr2[1] && tharr2[0] && tharr2[1]   ){
          var openHoursTimeTh = tConvert(tharr1[0]) + " - " + tConvert(tharr1[1])+', '+tConvert(tharr2[0]) + " - " + tConvert(tharr2[1]);
          var thursdayOpenHours = tConvert(tharr1[0]) + " - " + tConvert(tharr1[1])+', '+tConvert(tharr2[0]) + " - " + tConvert(tharr2[1]);
        }else if(tharr1[0] && tharr1[1] ||  tharr2[0] &&  tharr2[1] ){
          var ThmorShift = tConvert(tharr1[0]) + " - " + tConvert(tharr1[1]);
          var TheveShift = tConvert(tharr2[0]) + " - " + tConvert(tharr2[1]);
          if(ThmorShift){
            var openHoursTimeTh = ThmorShift;
            var thursdayOpenHours = ThmorShift;
          }else if(MeveShift){
            var openHoursTimeTh = TheveShift;
            var thursdayOpenHours = TheveShift;
          }
        }

        // Friday
        var farr1 = fri_morning_shift.split('-');
        var farr2 = fri_evening_shift.split('-');
        if(farr1[0] && farr2[1] && farr2[0] && farr2[1]   ){
          var openHoursTimeF = tConvert(farr1[0]) + " - " + tConvert(farr1[1])+', '+tConvert(farr2[0]) + " - " + tConvert(farr2[1]);
          var fridayOpenHours = tConvert(farr1[0]) + " - " + tConvert(farr1[1])+', '+tConvert(farr2[0]) + " - " + tConvert(farr2[1]);
        }else if(farr1[0] && farr1[1] ||  farr2[0] &&  farr2[1] ){
          var FmorShift = tConvert(farr1[0]) + " - " + tConvert(farr1[1]);
          var FeveShift = tConvert(farr2[0]) + " - " + tConvert(farr2[1]);
          if(FmorShift){
            var openHoursTimeF = FmorShift;
            var fridayOpenHours = FmorShift;
          }else if(MeveShift){
            var openHoursTimeF = FeveShift;
            var fridayOpenHours = FeveShift;
          }
        }else{
          if (window.location.href.indexOf("ar") > -1) { 
            var openHoursTimeF = "مغلق";
            var fridayOpenHours = "مغلق";
          }else{
            var openHoursTimeF = "Closed";
            var fridayOpenHours = "Closed";
          }
        }

        // Saturday
        var starr1 = sat_morning_shift.split('-');
        var starr2 = sat_evening_shift.split('-');
        if(starr1[0] && starr2[1] && starr2[0] && starr2[1]   ){
          var openHoursTimeSt = tConvert(starr1[0]) + " - " + tConvert(starr1[1])+', '+tConvert(starr2[0]) + " - " + tConvert(starr2[1]);
          var saturdayOpenHours = tConvert(starr1[0]) + " - " + tConvert(starr1[1])+', '+tConvert(starr2[0]) + " - " + tConvert(starr2[1]);
        }else if(starr1[0] && starr1[1] ||  starr2[0] &&  starr2[1] ){
          var StmorShift = tConvert(starr1[0]) + " - " + tConvert(starr1[1]);
          var SteveShift = tConvert(starr2[0]) + " - " + tConvert(starr2[1]);
          if(StmorShift){
            var openHoursTimeSt = StmorShift;
            var saturdayOpenHours = StmorShift;
          }else if(MeveShift){
            var openHoursTimeSt = SteveShift;
            var saturdayOpenHours = SteveShift;
          }
        }
      if (window.location.href.indexOf("ar") > -1) {
        var Monday = 'الإثنين';
        var Tuesday = 'الثلاثاء';
        var Wednesday = 'الأربعاء';
        var Thursday = 'الخميس';
        var Friday = 'يوم الجمعة';
        var Saturday = 'يوم السبت';
        var Sunday = 'الأحد';
        var Today = 'اليوم';                                                                                                                            
        var Opening_Hours = 'ساعات العمل';                                                                                                                            
      }else{
        var Monday = 'Monday';
        var Tuesday = 'Tuesday';
        var Wednesday = 'Wednesday';
        var Thursday = 'Thursday';
        var Friday = 'Friday';
        var Saturday = 'Saturday';
        var Sunday = 'Sunday';                                                            
        var Today = 'Today';                                                                    
        var Opening_Hours = 'Opening Hours';                                                                    
      }
      var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var dayName = days[new Date().getDay()];
    if(dayName == 'Sunday'){
      var workingHours = sundayOpenHours;
    }else if(dayName == 'Monday'){
      var workingHours = mondayOpenHours;
    }else if(dayName == 'Tuesday'){
      var workingHours = tuesdayOpenHours;
    }else if(dayName == 'Wednesday'){
      var workingHours = wednesdayOpenHours;
    }else if(dayName == 'Thursday'){
      var workingHours = thursdayOpenHours;
    }else if(dayName == 'Friday'){
      var workingHours = fridayOpenHours;
    }else if(dayName == 'Saturday'){
      var workingHours = saturdayOpenHours;
    }
        var center_address = center_address ? center_address : "";
        var infoContentStart = "<div class='info-window'>";
        var infoContentEnd = "</div>"
        var storeDescription = 
        "<div class='map-store-details'><h4> <span>"  
        + StoreLocationName + "</span>" + center_address + "</h4></div><div class='today-open-hours'><p>" + Opening_Hours + " </p><img src="+jQuery('#get-module-path').val()+"/img/clock_img.png><span>"+ Today +" :- </span><span>"+ workingHours +" </span><a target='_blank' href='https://www.google.com/maps?q="+ address_lat + "+" + address_long + "'><img src="+jQuery('#get-module-path').val()+"/img/direction_img.png></a></div><div class='show-view-more-data'><a href='javascript:;' id='view-more-time'>View More</a><a href='javascript:;' id='view-less-time'>View Less</a></div><div class='map-time-hour'>" 
        + "<span>" + openHours + " :- </span>" +  
        "<p class='outlet timing'> <span class='days'>"+ Sunday +"</span><span class='times'>" +  openHoursTimeSt + "</span></p><p class='outlet timing'><span class='days'>"+ Monday +"</span><span class='times'>" +  openHoursTimeM + "</span></p><p class='outlet timing'><span class='days'>"+ Tuesday +"</span><span class='times'>" +  openHoursTimeT + "</span></p><p class='outlet timing'> <span class='days'>"+ Wednesday +"</span><span class='times'>" +  openHoursTimeW + "</span></p><p class='outlet timing'> <span class='days' >"+ Thursday +"</span><span class='times'>" +  openHoursTimeTh + "</span></p><p class='outlet timing'> <span class='days' >"+ Friday +"</span><span class='times'>" +  openHoursTimeF + "</span></p><p class='outlet timing'> <span class='days'>"+ Saturday +"</span><span class='times'>" +  openHoursTimeSt + "</span></p></div>";
    infowindow.setContent(infoContentStart + storeDescription + infoContentEnd);                            
  }


})(jQuery, Drupal, drupalSettings);




