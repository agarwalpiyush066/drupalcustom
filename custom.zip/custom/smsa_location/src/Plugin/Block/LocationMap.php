<?php

namespace Drupal\smsa_location\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Provides a 'LocationMap' block.
 *
 * @Block(
 *  id = "location_map",
 *  admin_label = @Translation("Location Map Block"),
 * )
 */
class LocationMap extends BlockBase {

  public function build() {
    return array(
      '#theme' => 'location_map_block',
      '#variables' => NULL,
    );
  }
}