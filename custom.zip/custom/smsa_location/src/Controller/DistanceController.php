<?php


/**
 * @file contains
 */

namespace Drupal\smsa_location\Controller;

// Load the Twig theme engine so we can use twig_render_template().
include_once \Drupal::root() . '/core/themes/engines/twig/twig.engine';


use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
use SoapClient;
use Throwable;


class DistanceController extends ControllerBase {

  public function DistanceCalculate() {
    
  }

  /**
   * Function to fetch retail_centers_location contents.
   */
  public function fetchCenterLatLongData() {
    $location = [];
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
    if($language == 'en'){
      $language = 'En';
    }
    if( $language == 'ar' ){
      $language = 'Ar';
    }
    
    $city = \Drupal::request()->get('city');
    $country = \Drupal::request()->get('country');
    $country = $country ? $country : 'Saudi Arabia';
    $c_latitude = \Drupal::request()->get('c_lat');
    $c_longitude = \Drupal::request()->get('c_long');
    
  
    $latitude = $c_latitude;
    $longitude = $c_longitude;

    //$city = 'Mumbai';
    if (empty($city)) {
      $city = '';
      $data = [
        'country' => 'Saudi Arabia',
        'city' => '',
        'language' => (String) $language,
        'passkey' => 'rc$ervice',
      ];
    }
    else {
      /*$database = \Drupal::database();
      $query = $database->query("SELECT name FROM {taxonomy_term_field_data} WHERE tid =".$city);
      $result1 = $query->fetchAll();
      foreach ($result1 as $key => $value) {
          $cityname = $value->name;
      }*/
      
          $data = [
            'country' => $country,
            'city' => $city,
            'language' => (String) $language,
            'passkey' => 'rc$ervice',
          ];
    }
    $response = $this->apiRequestNew($data);

    $content = array();
    if(count($response->ListOfCentersResult->RetailRes, COUNT_RECURSIVE) == 1){
      $resultArray =  (array) $response->ListOfCentersResult->RetailRes;
      $content[] = $resultArray;
    } else {
      $result = json_decode(json_encode($response), true);
      $content = $result['ListOfCentersResult']['RetailRes'];
    }


    if (is_array($content)) {
      foreach ($content as $contentVal) {

        if((String) $language == 'En'){
          $center_name = $contentVal['City'];
          $center_address = $contentVal['Address1En'];
        }

        if((String) $language == 'Ar'){
          $center_name = $contentVal['CityAr'];
          $center_address = $contentVal['Address1Ar'];
        }

        $center_latitude = (float)$contentVal['GPSCoordinateLatitude'];
        $center_longitude = (float)$contentVal['GPSCoordinateLongitude'];
        $sunday_morning_shift_from = $contentVal['SunShift1From'].'-'.$contentVal['SunShift1To'];
        $sunday_evening_shift_from = $contentVal['SunShift2From'].'-'.$contentVal['SunShift2To'];
        $monday_morning_shift_from = $contentVal['MonShift1From'].'-'.$contentVal['MonShift1To'];
        $monday_evening_shift_from = $contentVal['MonShift2From'].'-'.$contentVal['MonShift2To'];
        $tuesday_morning_shift_from = $contentVal['TueShift1From'].'-'.$contentVal['TueShift1To'];
        $tuesday_evening_shift_from = $contentVal['TueShift2From'].'-'.$contentVal['TueShift2To'];
        $wednesday_morning_shift_from = $contentVal['WedShift1From'].'-'.$contentVal['WedShift1To'];
        $wednesday_evening_shift_from = $contentVal['WedShift2From'].'-'.$contentVal['WedShift2To'];
        $thursday_morning_shift_from = $contentVal['ThuShift1From'].'-'.$contentVal['ThuShift1To'];
        $thursday_evening_shift_from = $contentVal['ThuShift1To'].'-'.$contentVal['ThuShift2To'];
        $friday_morning_shift_from = $contentVal['FriShift1From'].'-'.$contentVal['FriShift1To'];
        $friday_evening_shift_from = $contentVal['FriShift2To'].'-'.$contentVal['FriShift2From'];
        $saturday_morning_shift_from = $contentVal['SatShift1From'].'-'.$contentVal['SatShift1To'];
        $saturday_evening_shift_from = $contentVal['SatShift2From'].'-'.$contentVal['SatShift2To'];
        $morning_shift = '';
        $evening_shift = '';
        $arr[] = [
          $center_name, 
          $sunday_morning_shift_from,
          $sunday_evening_shift_from,
          $monday_morning_shift_from,
          $monday_evening_shift_from,
          $tuesday_morning_shift_from,
          $tuesday_evening_shift_from,
          $wednesday_morning_shift_from,
          $wednesday_evening_shift_from,
          $thursday_morning_shift_from,
          $thursday_evening_shift_from,
          $friday_morning_shift_from,
          $friday_evening_shift_from,
          $saturday_morning_shift_from,
          $saturday_evening_shift_from,
          $center_latitude, 
          $center_longitude, 
          $center_address];
      }
      $result = array_merge($location, $arr);

    }

    // create center list
    $list_data = fetch_retail_center_data($city, NULL, $latitude, $longitude);
    

    $markup = twig_render_template(drupal_get_path('module', 'smsa_location') . '/templates/location-map-table.html.twig', array(
      'retail_center_data' => $list_data,
      'base_url' => $this->getBaseUrl(),
      // Needed to prevent notices when Twig debugging is enabled.
      'theme_hook_original' => 'not-applicable',
    ));
    $resultJson = json_encode($result, JSON_UNESCAPED_UNICODE);
    /*return new JsonResponse([
      'langlong' => $resultJson,
      'retail_center_data' => (String) $markup,
      'method' => 'POST',
    ]);*/
    $response = new JsonResponse();
    $response->setData([
      'langlong' => $result,
      'retail_center_data' => (String) $markup,
      'method' => 'POST',
    ]);
    $response->setEncodingOptions(JSON_UNESCAPED_UNICODE);
    return $response;
    
  }
  public function apiRequestNew($data){

    $client = new SoapClient("http://smsamobilepro.cloudapp.net/retailcenter.asmx?op=ListOfCenters&wsdl");
    try {
      //Invoke WS method (Function1) with the request params
      $response = $client->__soapCall("ListOfCenters", array($data));
    }
    catch(Throwable $e){
        echo 'sorry... our web service is down';
      }
    return $response;
  }


  function getBaseUrl() {
    $base_path = \Drupal::urlGenerator()->generateFromRoute('<front>', [], ['absolute' => TRUE]);
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
    if ($language != 'en') {
      $baseURL = $base_path . '/';
    }
    else {
      $baseURL = $base_path;
    }
    $baseURL = preg_replace('#\/[^/]*$#', '', $base_path);
    return $baseURL;
  }

}
