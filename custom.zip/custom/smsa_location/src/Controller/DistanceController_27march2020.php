<?php


/**
 * @file contains
 */

namespace Drupal\smsa_location\Controller;

// Load the Twig theme engine so we can use twig_render_template().
include_once \Drupal::root() . '/core/themes/engines/twig/twig.engine';


use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;

class DistanceController extends ControllerBase {

  public function DistanceCalculate() {
    $lat1 = \Drupal::request()->get('lat_from');
    $lon1 = \Drupal::request()->get('long_from');
    $lat2 = '';
    $lon2 = '';
    $location_city = \Drupal::request()->get('city');

    $query = \Drupal::entityQuery('node');
    $query->condition('status', 1);
    $query->condition('type', 'retail_centers_location');
    $city = '';
    if ($city) {
      $query->condition('field_region_city', $location_city);
    }
    $nids = $query->execute();

    $distance = [];
    if ($nids) {
      foreach ($nids as $nid) {
        $node = \Drupal\node\Entity\Node::load($nid);
        $lat2 = $node->get('field_latitude')->getValue()[0]['value'];
        $lon2 = $node->get('field_longitude')->getValue()[0]['value'];

        if (($lat1 != $lat2) && ($lon1 != $lon2)) {
          $theta = $lon1 - $lon2;
          $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
          $dist = acos($dist);
          $dist = rad2deg($dist);
          $miles = $dist * 60 * 1.1515;
          $distance[$nid] = round($miles * 1.609344, 2) . t('KM');
        }
      }
    }

    return new JsonResponse([
      'distance' => $distance,
      'method' => 'POST',
    ]);
  }

  /**
   * Function to fetch retail_centers_location contents.
   */
  public function fetchCenterLatLongData() {
    $location = [];

    $city = \Drupal::request()->get('city');
    $query = \Drupal::entityQuery('node');
    $query->condition('status', 1);
    $query->condition('type', 'retail_centers_location');
    //$city = 'Mumbai';
    if (empty($city)) {
      $city = '';
    }
    else {
      $query->condition('field_region_city', $city);
    }

    $nids = $query->execute();
    if ($nids) {
      foreach ($nids as $nid) {
        $node = Node::load($nid);
        $center_name = $node->title->value;
        $center_latitude = (float)$node->get('field_latitude')->getValue()[0]['value'];
        $center_longitude = (float)$node->get('field_longitude')->getValue()[0]['value'];
        $arr[] = [$center_name, $center_latitude, $center_longitude];
      }
      $result = array_merge($location, $arr);
    }
    // create center list
    $list_data = fetch_retail_center_data($city, NULL);
    $markup = twig_render_template(drupal_get_path('module', 'smsa_location') . '/templates/location-map-table.html.twig', array(
      'retail_center_data' => $list_data,
      'base_url' => $this->getBaseUrl(),
      // Needed to prevent notices when Twig debugging is enabled.
      'theme_hook_original' => 'not-applicable',
    ));
    return new JsonResponse([
      'langlong' => $result,
      'retail_center_data' => (String) $markup,
      'method' => 'POST',
    ]);
  }

  function getBaseUrl() {
    $base_path = \Drupal::urlGenerator()->generateFromRoute('<front>', [], ['absolute' => TRUE]);
    $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
    if ($language != 'en') {
      $baseURL = $base_path . '/';
    }
    else {
      $baseURL = $base_path;
    }
    $baseURL = preg_replace('#\/[^/]*$#', '', $base_path);
    return $baseURL;
  }

}
